using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//ָ�������
public class IntroductorController
{
    public static IntroductorController Instance;

    public GameObject introductor;

    public List<Cell> cells;

    public FightUnit fightUnit;

    public void Init()
    {
        cells = new List<Cell>();
        GameObject intrObj = GameObject.Instantiate(Resources.Load("introductor/Introductor")) as GameObject;
        intrObj.transform.SetParent(GameObject.Find("Canvas/IntroductorPos").transform);
        intrObj.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, 0);
        Introductor intrItem = intrObj.AddComponent<Introductor>();
        intrObj.transform.SetAsFirstSibling();
        intrObj.transform.localScale = Vector3.one * UiFitter.ScaleFitHorizontal(1);
        intrObj.transform.name = "Introductor";
        intrItem.Init();
        this.introductor = intrObj;
        //��ÿ��cell���Ͻű�
        for(int i = 0; i < 5; i++)
        {
            GameObject cellObj = GameObject.Find("Canvas/IntroductorPos/Introductor/Cell" + i.ToString());
            Cell cellItem = cellObj.AddComponent<Cell>() as Cell;
            cells.Add(cellItem);
            intrObj.GetComponent<Introductor>().cells.Add(cellItem);
            if(i < RoleManager.Instance.mostIntrodutors)
            {
                cellItem.isValid = true;
            }
            else
            {
                cellItem.isValid = false;
            }
            cellItem.Init();
        }
    }

    public void ClearIntroductor()
    {
        introductor.GetComponent<Introductor>().SelfDestroy();
    }

    public void UpdateAllValidTxt()
    {
        for(int i = 0; i < RoleManager.Instance.mostIntrodutors; i++)
        {
            cells[i].UpdateTxt();
        }
    }

    public void UpdateAllTxt()
    {
        foreach (Cell item in cells)
        {
            item.UpdateTxt();
        }
    }
}
