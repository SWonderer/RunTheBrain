using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

/// <summary>
/// �����ڽ���Ч����
/// </summary>
public class RewardEff : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public Button ReBtn;

    public string effTitle;
    public string effDes;

    void Awake()
    {
        ReBtn = GetComponentInChildren<Button>();
        ReBtn.onClick.AddListener(OnClickThisBtn);
    }

    public void OnClickThisBtn()
    {
        EndBattlePanel.Instance.ClearAllEffRewards();
        RoleManager.Instance.fieldEffects += "," + GameObject.Find(this.gameObject.name + "/BackGround").GetComponentInChildren<NameTagger>().nameTag;
    }

    public void SelfDestory()
    {
        Destroy(this.gameObject);
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        UIManager.Instance.ShowDesContainer(this.gameObject.GetComponent<RectTransform>().anchoredPosition * 1.2f
            , effTitle, effDes, Color.white);
        UIManager.Instance.SetDesContainerLastSibling();
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        UIManager.Instance.DestoyAllDesContainer();
    }

    private void OnDestroy()
    {
        UIManager.Instance.DestoyAllDesContainer();
    }
}
