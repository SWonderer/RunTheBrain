using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum FightUnit
{
    PlayerTurn,
    EnemyTurn,
    None
}


public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    public void Awake()
    {
        Instance = this;

        //Screen.SetResolution(2560, 1440, true);

        MapController.Instance = new MapController();

        LevelManager.Instance = new LevelManager();

        PlayerController.Instance = new PlayerController();

        CardController.Instance = new CardController();

        RoleManager.Instance = new RoleManager();

        IntroductorController.Instance = new IntroductorController();

        EffectController.Instance = new EffectController();

        EnemyController.Instance = new EnemyController();
    }

    public void Start()
    {
        GameConfigManager.Instance.Init();
        UIManager.Instance.Init();
        RoleManager.Instance.Init();

        //test
        //Debug.Log(GameConfigManager.Instance.GetEnemyById("1001")["ActList"]);

        //test
        //EnemyController.Instance.Hurt(50);

        //test
        //PlayerController.Instance.Hurt(50);

        //print(PlayerController.Instance.curHp);

        //test
        //Invoke("PlayerMove1", 1.5f);
        //Invoke("PlayerMove2", 3.0f);
        //Invoke("PlayerMove3", 4.5f);
        //Invoke("PlayerMove4", 6.0f);
    }

    //public void PlayerMove1()
    //{
    //    PlayerController.Instance.Move(MoveDirection.Up, 2);
    //}

    //public void PlayerMove2()
    //{
    //    PlayerController.Instance.Move(MoveDirection.Down, 2);
    //}

    //public void PlayerMove3()
    //{
    //    PlayerController.Instance.Move(MoveDirection.Right, 2);
    //}

    //public void PlayerMove4()
    //{
    //    PlayerController.Instance.Move(MoveDirection.Left, 2);
    //}

    public void Update()
    {
        //PlayerController.Instance.UpdateHpBar();
    }

    public void FightSceneInit()
    {
        MapController.Instance.InitMapSize();
        PlayerController.Instance.Init();
        EnemyController.Instance.Init();
        MapController.Instance.GenerateMapBySize(MapController.Instance.mapWidth,
            MapController.Instance.mapHeight);
        PlayerController.Instance.CreatePlayer(-110 * (MapController.Instance.mapWidth - 1),
            -110 * (MapController.Instance.mapHeight - 1));
        PlayerController.Instance.GetPlayerPos(new Vector2(0, MapController.Instance.mapHeight - 1));
        CardController.Instance.Init();
        IntroductorController.Instance.Init();
        EffectController.Instance.InitData();
        EffectController.Instance.Refesh();
        PlayerController.Instance.PlayerActStart();
    }

    public void FightSceneClear()
    {
        MapController.Instance.ClearMap();
        CardController.Instance.ClearAllHandCards();
        PlayerController.Instance.ClearPlayerObj();
        EnemyController.Instance.ClearEnemy();
        IntroductorController.Instance.ClearIntroductor();
    }
}

