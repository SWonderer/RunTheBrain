using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//�������������
public class BaseField : MonoBehaviour 
{
    public Image thisImage;
    public GameObject AtkIcon;
    public GameObject PoisonIcon;
    public GameObject BlockIcon;
    public GameObject DrawCardsIcon;
    public GameObject StrengthIcon;
    public GameObject AgilityIcon;
    public GameObject HealIcon;
    public GameObject AutoHitIcon;
    public GameObject AvoidIcon;
    public GameObject WeaknessIcon;
    public GameObject AutoMoveIcon;
    public List<GameObject> icons = new List<GameObject>();
    public Text valTxt;

    public void Awake()
    {
        thisImage = this.GetComponent<Image>();
        AtkIcon = GameObject.Find(this.gameObject.name + "/AtkIcon");
        icons.Add(AtkIcon);
        PoisonIcon = GameObject.Find(this.gameObject.name + "/PoisonIcon");
        icons.Add(PoisonIcon);
        BlockIcon = GameObject.Find(this.gameObject.name + "/BlockIcon");
        icons.Add(BlockIcon);
        DrawCardsIcon = GameObject.Find(this.gameObject.name + "/DrawCardsIcon");
        icons.Add(DrawCardsIcon);
        StrengthIcon = GameObject.Find(this.gameObject.name + "/StrengthIcon");
        icons.Add(StrengthIcon);
        AgilityIcon = GameObject.Find(this.gameObject.name + "/AgilityIcon");
        icons.Add(AgilityIcon);
        HealIcon = GameObject.Find(this.gameObject.name + "/HealIcon");
        icons.Add(HealIcon);
        AutoHitIcon = GameObject.Find(this.gameObject.name + "/AutoHitIcon");
        icons.Add(AutoHitIcon);
        AvoidIcon = GameObject.Find(this.gameObject.name + "/AvoidIcon");
        icons.Add(AvoidIcon);
        WeaknessIcon = GameObject.Find(this.gameObject.name + "/WeaknessIcon");
        icons.Add(WeaknessIcon);
        AutoMoveIcon = GameObject.Find(this.gameObject.name + "/AutoMoveIcon");
        icons.Add(AutoMoveIcon);
        valTxt = GetComponentInChildren<Text>();
    }

    public void Update()
    {
        if(this.GetComponent(System.Type.GetType("BaseEffect")) == null)
        {
            //AtkIcon.SetActive(false);
            //PoisonIcon.SetActive(false);
            //BlockIcon.SetActive(false);
            //DrawCardsIcon.SetActive(false);
            //StrengthIcon.SetActive(false);
            //AgilityIcon.SetActive(false);
            for (int i = 0; i < icons.Count; i++)
            {
                icons[i].SetActive(false);
            }
            valTxt.text = "";
        }
    }

    public void UpdateColor(Color color)
    {
        thisImage.color = color;
    }

    public void SelfDestroy()
    {
        Destroy(this.gameObject);
    }
}
