using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FPSLimit : MonoBehaviour
{
	void Start()
	{
		//֡������Ϊ 30
		Application.targetFrameRate = 120;
	}
}
