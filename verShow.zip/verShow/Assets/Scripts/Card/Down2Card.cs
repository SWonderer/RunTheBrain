using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Down2Card : CardItem
{
    public void Start()
    {
        dir = MoveDirection.Down;
        step = 2;
    }
}
