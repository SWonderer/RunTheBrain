using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Up1Card : CardItem
{
    public void Start()
    {
        dir = MoveDirection.Up;
        step = 1;
    }
}
