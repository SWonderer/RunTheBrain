using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using DG.Tweening;
using System;

public class CardItem : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IBeginDragHandler, IDragHandler, IEndDragHandler, IPointerDownHandler
{
    public MoveDirection dir;
    public int step;

    private int index;

    public void OnPointerEnter(PointerEventData eventData)
    {
        transform.DOScale(1.25f, 0.25f);
        index = transform.GetSiblingIndex();
        transform.SetAsLastSibling();

        transform.GetComponent<Image>().material.SetColor("_lineColor", Color.yellow);
        transform.GetComponent<Image>().material.SetFloat("_lineWidth", 10);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        transform.DOScale(1.0f, 0.25f);
        transform.SetSiblingIndex(index);

        transform.GetComponent<Image>().material.SetColor("_lineColor", Color.yellow);
        transform.GetComponent<Image>().material.SetFloat("_lineWidth", 10);
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        ////�ر�����Э��
        //StopAllCoroutines();
        ////����������Э��
        //StartCoroutine(OnMouseDownRight(eventData));
    }

    //IEnumerator OnMouseDownRight(PointerEventData pData)
    //{
    //    while (true)
    //    {
    //        //�������߼�� �Ƿ��⵽ָ����
    //        //CheckRayToIntroductor();
    //        yield return null;
    //    }
    //}

    Vector2 initPos;

    public void OnBeginDrag(PointerEventData eventData)
    {
        initPos = transform.GetComponent<RectTransform>().anchoredPosition;
    }

    public void OnDrag(PointerEventData eventData)
    {
        Vector2 pos;
        if (RectTransformUtility.ScreenPointToLocalPointInRectangle(
            transform.parent.GetComponent<RectTransform>(),
            eventData.position,
            eventData.pressEventCamera,
            out pos
            ))
        {
            transform.GetComponent<RectTransform>().anchoredPosition = pos;
        }
        CheckRayToIntroductor(pos);
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        transform.GetComponent<RectTransform>().anchoredPosition = initPos;
        transform.SetSiblingIndex(index);
    }

    public void SelfDestroy()
    {
        Destroy(this.gameObject);
    }

    Introductor introductor;
    //����Ƿ�����Introductor
    public void CheckRayToIntroductor(Vector2 pos)
    {
        //Ray ray = new Ray(pos, Vector3.forward);

        ////Debug.DrawRay(Input.mousePosition, Vector3.forward, Color.red);

        ////print(Input.mousePosition);

        //print(1);

        //RaycastHit hit;

        //if (Physics.Raycast(ray, out hit, 10000, LayerMask.GetMask("Introductor")))
        //{
        //    introductor = hit.transform.GetComponent<Introductor>();

        //    print(2);
        //}

        GameObject obj = GetFirstPickGameObject(pos + new Vector2(Screen.width / 2, 0));

        if(obj != null)
        {
            if (obj.tag == "Introductor")
            {
                introductor = obj.GetComponent<Introductor>();
                //print(introductor.transform.name);
                for(int i = 0; i < introductor.cells.Count; i++)
                {
                    if (!introductor.cells[i].isValid)
                        break;
                    if (!introductor.cells[i].hasAct)
                    {
                        introductor.cells[i].dir = this.dir;
                        introductor.cells[i].step = this.step;
                        introductor.cells[i].hasAct = true;
                        introductor.cells[i].UpdateTxt();
                        //print("CardController.Instance.handCardObjs:" + CardController.Instance.handCardObjs.Count);
                        //print("CardController.Instance.handCardList:" + CardController.Instance.handCardList.Count);
                        CardController.Instance.handCardObjs.Remove(this.gameObject);
                        CardController.Instance.handCardList.Remove(this.gameObject.name);
                        //print(this.gameObject.name);
                        //CardController.Instance.UpdateHandCardPos();
                        //print("CardController.Instance.handCardObjs:" + CardController.Instance.handCardObjs.Count);
                        //print("CardController.Instance.handCardList:" + CardController.Instance.handCardList.Count);
                        Destroy(this.gameObject);
                        break;
                    }
                    else
                        continue;
                }
            }
        }
    }

    public GameObject GetFirstPickGameObject(Vector2 position)
    {
        EventSystem eventSystem = EventSystem.current;
        PointerEventData pointerEventData = new PointerEventData(eventSystem);
        pointerEventData.position = position;
        //���߼��ui
        List<RaycastResult> uiRaycastResultCache = new List<RaycastResult>();
        eventSystem.RaycastAll(pointerEventData, uiRaycastResultCache);
        if (uiRaycastResultCache.Count > 0)
            return uiRaycastResultCache[0].gameObject;
        return null;
    }
}