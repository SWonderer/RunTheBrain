using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//��ͼ������
public class MapController
{
    public static MapController Instance;

    //��ȡlevel�ļ�
    public Dictionary<string, string> levelData;

    public int levelId;

    //��ͼ�ߴ�
    public int mapHeight;
    public int mapWidth;    

    //��ͼ���Ӵ�������
    public GameObject[,] mapFields;

    public void InitMapSize()
    {
        levelData = GameConfigManager.Instance.GetLevelById(levelId.ToString());

        mapHeight = int.Parse(levelData["MapHeight"]);
        mapWidth = int.Parse(levelData["MapWidth"]);
    }

    //���ɵ�ͼ
    public void GenerateMapBySize(int width, int height)
    {
        mapFields = new GameObject[width, height];

        for(int i = 0; i < height; i++)
        {
            for (int j = 0; j < width; j++)
            {
                GameObject fieldobj = GameObject.Instantiate(Resources.Load("map/mapField")) as GameObject;
                mapFields[j, i] = fieldobj;
                fieldobj.AddComponent<BaseField>();
                fieldobj.transform.SetParent(GameObject.Find("Canvas/mapFields").transform);
                fieldobj.transform.localScale = Vector3.one * UiFitter.ScaleFitHorizontal(1);
                fieldobj.name = "mapField" + (j + i * 3).ToString();
                fieldobj.transform.SetAsFirstSibling();
                fieldobj.GetComponent<RectTransform>().anchoredPosition = new Vector2(-110 * (width - 1) + j * 220, 110 * (height - 1) - i * 220);
            }
        }
        Debug.Log("field0Pos:" + mapFields[0, 0].transform.GetComponent<RectTransform>().anchoredPosition);
    }

    //�����ͼ��Ϸ����
    public void ClearMap()
    {
        for(int i = 0; i < mapHeight; i++)
        {
            for(int j = 0; j < mapWidth; j++)
            {
                mapFields[i, j].GetComponent<BaseField>().SelfDestroy();
            }
        }
    }
}
