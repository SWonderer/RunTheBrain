using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Effect_Shield : BaseEffect
{
    public void Awake()
    {
        for (int i = 0; i < this.GetComponent<BaseField>().icons.Count; i++)
        {
            this.GetComponent<BaseField>().icons[i].SetActive(false);
        }
        this.GetComponent<BaseField>().BlockIcon.SetActive(true);
    }

    public override void StrikeEffect()
    {
        AgilityAdd(PlayerController.Instance.agility);
        PlayerController.Instance.GetShield(val);
        Debug.Log("�����˼Ӷܸ��Ч��" + val);
    }

    public void AgilityAdd(int agility)
    {
        val += agility;
    }
}
