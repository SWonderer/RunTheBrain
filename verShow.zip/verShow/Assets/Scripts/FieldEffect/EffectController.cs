using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// ����Effect
/// ���ܣ�����һ�����effect�б�
/// Ȼ����������и����ϣ�����������ڸ��ӣ�
/// </summary>
public class EffectController
{
    public static EffectController Instance;

    public List<string> effectsList = new List<string>();
    public List<int> numList = new List<int>();
    public List<int> effectFieldIndex = new List<int>();

    public Dictionary<string, string> levelData = new Dictionary<string, string>();

    public List<Dictionary<string, string>> effectDataList = new List<Dictionary<string, string>>();

    public int levelId;

    public void InitData()
    {
        effectDataList = GameConfigManager.Instance.GetEffectLines();
        levelData = GameConfigManager.Instance.GetLevelById(levelId.ToString());
    }

    public void Refesh()
    {
        //����RoleManager.Instance.fieldEffects��List�����Effect
        string[] tempList = RoleManager.Instance.fieldEffects.Trim().Split(",");
        for(int i = 0; i < tempList.Length; i++)
        {
            int num = 0;
            int n = 0;
            string tempStr = "";
            for (int j = 0; j < tempList[i].Length; j++)
            {
                if (isNum(tempList[i][j].ToString(), n))
                {
                    num = int.Parse(tempList[i][j].ToString()) + num * 10;
                }
                else
                {
                    tempStr += tempList[i][j].ToString();
                }
            }
            AddEffect(tempStr, num);
        }
        ClearMapEffects();
        GetRandomIndex();
        AddEffectListToField();
    }

    public bool isNum(string s, int re)
    {
        bool isnum = false;
        isnum = int.TryParse(s, out re);
        return isnum;
    }

    //��Ч���б���ͬʱ������ֵ��Ч��
    public void AddEffect(string effName, int effNum)
    {
        effectsList.Add(effName);
        numList.Add(effNum);
    }

    //�����ͼ�����е�Ч��
    public void ClearMapEffects()
    {
        for (int i = 0; i < MapController.Instance.mapHeight; i++)
        {
            for (int j = 0; j < MapController.Instance.mapWidth; j++)
            {
                if (effectFieldIndex.Contains(i * MapController.Instance.mapWidth + j))
                {
                    BaseEffect effectItem = MapController.Instance.mapFields[j, i].GetComponent(System.Type.GetType("BaseEffect")) as BaseEffect;
                    if(effectItem != null)
                        effectItem.DestroyThisItem();
                }
            }
        }
    }

    public void GetRandomIndex()
    {
        //��ȡ�͵�ͼ����Ч��������ͬ�����index�ĵ�ͼ�������� ���ܳ�����ͼ�ܸ�������
        effectFieldIndex.Clear();
        while (effectFieldIndex.Count < effectsList.Count 
            && effectFieldIndex.Count < MapController.Instance.mapWidth * MapController.Instance.mapHeight - 1)
        {
            int index = Random.Range(0, MapController.Instance.mapHeight *
                MapController.Instance.mapWidth);
            //����õ����index���ظ��Ҳ�Ϊ������ڸ��� ��ʹ���������
            if (!effectFieldIndex.Contains(index) && index != (int)(PlayerController.Instance.playerPos.y * MapController.Instance.mapWidth
                 + PlayerController.Instance.playerPos.x))
                effectFieldIndex.Add(index);
            else
                continue;
        }
    }

    public void AddEffectListToField()
    {
        for(int i = 0; i < MapController.Instance.mapHeight; i++)
        {
            for(int j = 0; j < MapController.Instance.mapWidth; j++)
            {
                //���ָ�����������
                if(effectFieldIndex.Contains(i * MapController.Instance.mapWidth + j))
                {
                    int randIndex = Random.Range(0, effectsList.Count);
                    //��Effect�ű�
                    BaseEffect effectItem = MapController.Instance.mapFields[j, i].AddComponent(
                        System.Type.GetType(effectsList[randIndex])) as BaseEffect;
                    effectItem.val = numList[randIndex];
                    effectItem.GetComponentInChildren<Text>().text = effectItem.val.ToString();

                    for(int m = 0; m < effectDataList.Count; m++)
                    {
                        if (effectDataList[m]["effectName"] == effectsList[randIndex])
                        {
                            effectItem.effTitle = effectDataList[m]["title"];
                            effectItem.effDes = effectDataList[m]["des"];
                        }
                    }

                    effectsList.RemoveAt(randIndex);
                    numList.RemoveAt(randIndex);
                }
            }
        }
    }
}
