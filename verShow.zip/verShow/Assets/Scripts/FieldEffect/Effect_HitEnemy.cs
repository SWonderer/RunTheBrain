using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Effect_HitEnemy : BaseEffect
{
    public void Awake()
    {
        effName = "Effect_HitEnemy";
        for (int i = 0; i < this.GetComponent<BaseField>().icons.Count; i++)
        {
            this.GetComponent<BaseField>().icons[i].SetActive(false);
        }
        this.GetComponent<BaseField>().AtkIcon.SetActive(true);
    }

    public override void StrikeEffect()
    {
        StrengthAdd(PlayerController.Instance.strength);
        EnemyController.Instance.Hurt(val);
        Debug.Log("�����˹������Ч��" + val);
    }

    public void StrengthAdd(int strength)
    {
        val += strength;
    }
}
