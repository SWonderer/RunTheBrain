using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Effect_AutoMove : BaseEffect
{
    public void Awake()
    {
        for (int i = 0; i < this.GetComponent<BaseField>().icons.Count; i++)
        {
            this.GetComponent<BaseField>().icons[i].SetActive(false);
        }
        this.GetComponent<BaseField>().AutoMoveIcon.SetActive(true);
    }

    public override void StrikeEffect()
    {
        PlayerController.Instance.autoMoveWhenActStart += val;
        Debug.Log("�����������Զ��ƶ����Ч��" + val);
    }
}
