using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Effect_Weakness : BaseEffect
{
    public void Awake()
    {
        for (int i = 0; i < this.GetComponent<BaseField>().icons.Count; i++)
        {
            this.GetComponent<BaseField>().icons[i].SetActive(false);
        }
        this.GetComponent<BaseField>().WeaknessIcon.SetActive(true);
    }

    public override void StrikeEffect()
    {
        GameObject.Find("Canvas/Enemy").GetComponentInChildren<EnemyBase>().atkWeakVal += val;
        Debug.Log("�������������Ч��" + val);
    }
}
