using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// �ļ�����ӳ���� һ���ļ���Ӧһ��ӳ��
/// </summary>
public class GameConfig
{
    public List<Dictionary<string, string>> config;

    public GameConfig(string str)
    {
        config = new List<Dictionary<string, string>>();

        //�����и�
        string[] lines = str.Split("\n");
        //��ȡĿ¼���� Ϊlines[0]
        string[] titles = lines[0].Trim().Split("\t");

        for(int i = 1; i < lines.Length; i++)
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            string[] thisline = lines[i].Trim().Split("\t");
            for(int j = 0; j < thisline.Length; j++)
            {
                dic.Add(titles[j], thisline[j]);
            }
            config.Add(dic);
        }
    }

    public List<Dictionary<string, string>> GetLines()
    {
        return config;
    }

    public Dictionary<string, string> GetLinesById(string id)
    {
        for(int i = 0; i < config.Count; i++)
        {
            Dictionary<string, string> dic = config[i];
            if (dic["id"] == id)
            {
                return dic;
            }
        }
        return null;
    }
}
