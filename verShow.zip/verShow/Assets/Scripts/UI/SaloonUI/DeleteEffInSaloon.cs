using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DeleteEffInSaloon : MonoBehaviour
{
    public string effType;
    public string effVal;

    public List<string> effTypeList = new List<string>();
    public List<string> effValList = new List<string>();

    public Button effBtn;

    public void Awake()
    {
        effBtn = GetComponent<Button>();
        effBtn.onClick.AddListener(OnClickEffBtn);
    }

    //���°�ť ɾ��Rolemanager�еĶ�Ӧ��ͼ������Ϣ
    public void OnClickEffBtn()
    {
        for(int i = 0; i < effTypeList.Count; i++)
        {
            if(effTypeList[i] == effType && effValList[i] == effVal)
            {
                effTypeList.RemoveAt(i);
                effValList.RemoveAt(i);
            }
        }
        string myEffs = "";
        for (int i = 0; i < effTypeList.Count; i++)
        {
            myEffs += effTypeList[i];
            myEffs += effValList[i];
            if(i != effTypeList.Count - 1)
                myEffs += ",";
        }
        RoleManager.Instance.fieldEffects = myEffs;

        //����effpanel���������UI������LevelUI
        UIManager.Instance.ClearAllUI();
        UIManager.Instance.CreateUIByName("LevelUI");
        Destroy(GameObject.Find("EffPanel"));
    }
}
