using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEditor;

public class LoginUI : UIBase
{
    public Button startBtn;
    public Button exitBtn;

    public void Awake()
    {
        startBtn = GameObject.Find("StartGame").GetComponent<Button>();
        exitBtn = GameObject.Find("ExitGame").GetComponent<Button>();
        startBtn.onClick.AddListener(OnClickStartBtn);
        exitBtn.onClick.AddListener(OnClickExitBtn);
    }

    public void OnClickStartBtn()
    {
        //����LoginUI �����㼶UI
        UIManager.Instance.ClearAllUI();
        UIManager.Instance.CreateUIByName("LevelUI");
    }

    public void OnClickExitBtn()
    {
#if UNITY_EDITOR        //Unity�༭���е���ʹ��
        EditorApplication.isPlaying = false;
#else                   //������Ϸ����ʹ��
        Application.Quit();
#endif
    }

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
