using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TruesureUI : UIBase
{
    public Button GetTruesureBtn;
    public Button WalkawayBtn;

    // Start is called before the first frame update
    void Start()
    {
        GetTruesureBtn = GameObject.Find("GetTruesureBtn").GetComponent<Button>();
        GetTruesureBtn.onClick.AddListener(OnClickGetTruesureBtn);
        WalkawayBtn = GameObject.Find("WalkawayBtn").GetComponent<Button>();
        WalkawayBtn.onClick.AddListener(OnClickWalkawayBtn);
    }

    //��ñ��ذ�ť��60���ʻ�õ�ͼ���ӣ�20���ʻ�ÿ��ƣ�10���ʻ�ý�ɫ���ӣ�10���ʵ�30%Ѫ��
    public void OnClickGetTruesureBtn()
    {
        int randNum = Random.Range(1, 100);
        string info = "";
        if(randNum < 60)
        {
            string effName = RandEffManager.GetRandEff();
            RoleManager.Instance.fieldEffects += ("," + effName);
            info = ("����˸��ӣ�" + effName);
        }
        else if(randNum < 80)
        {
            int randNum2 = Random.Range(1, 6);
            string cardName = "noCard";
            switch (randNum)
            {
                case 1:
                    cardName = "Down0Card";
                    break;
                case 2:
                    cardName = "Down2Card";
                    break;
                case 3:
                    cardName = "Up2Card";
                    break;
                case 4:
                    cardName = "Right2Card";
                    break;
                case 5:
                    cardName = "Left2Card";
                    break;
                default:
                    break;
            }
            RoleManager.Instance.playerCards.Add(cardName);
            info = ("����˿��ƣ�" + cardName);
        }
        else if(randNum < 90)
        {
            string effName = RandEffManager.GetRandGoldEff();
            RoleManager.Instance.fieldEffects += ("," + effName);
            info = ("����˽�ɫ��ͼ����Ч����" + effName);
        }
        else
        {
            RoleManager.Instance.curHp -= (int)(RoleManager.Instance.maxHp * 0.3f);
            info = "�Ǳ���֣�����30%Ѫ";
        }
        UIManager.Instance.ShowTip(info, Color.red);
        UIManager.Instance.ClearAllUI();
        UIManager.Instance.CreateUIByName("LevelUI");
    }

    //�߿� �رս���
    public void OnClickWalkawayBtn()
    {
        UIManager.Instance.ClearAllUI();
        UIManager.Instance.CreateUIByName("LevelUI");
    }
}
