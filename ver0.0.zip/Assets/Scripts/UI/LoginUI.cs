using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LoginUI : UIBase
{
    public Button startBtn;
    public Button exitBtn;

    public void Awake()
    {
        startBtn = GameObject.Find("StartGame").GetComponent<Button>();
        exitBtn = GameObject.Find("ExitGame").GetComponent<Button>();
        startBtn.onClick.AddListener(OnClickStartBtn);
        exitBtn.onClick.AddListener(OnClickExitBtn);
    }

    public void OnClickStartBtn()
    {
        //����LoginUI �����㼶UI
        UIManager.Instance.ClearAllUI();
        UIManager.Instance.CreateUIByName("LevelUI");
    }

    public void OnClickExitBtn()
    {

    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
