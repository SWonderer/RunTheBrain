using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SaloonLevel : BaseLevel
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public override void OnClickLevelBtn()
    {
        //�޸�Ϊ���ɾƹ�UI
        UIManager.Instance.ClearAllUI();
        UpdateLevelId(levelId);
        UIManager.Instance.CreateUIByName("SaloonUI");
    }
}
