using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BaseLevel : MonoBehaviour
{
    public int levelId;

    public Button selfbtn;

    public string levelKind = "BaseLevel";
    private void Awake()
    {
        selfbtn = GetComponent<Button>();
        selfbtn.onClick.AddListener(OnClickLevelBtn);
    }

    public virtual void OnClickLevelBtn()
    {
        //��������UI������ս��UI
        UIManager.Instance.ClearAllUI();
        UpdateLevelId(levelId);
        UIManager.Instance.CreateFightScene();
    }

    public void UpdateLevelId(int id)
    {
        MapController.Instance.levelId = id;
        EffectController.Instance.levelId = id;
        EnemyController.Instance.levelId = id;
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
