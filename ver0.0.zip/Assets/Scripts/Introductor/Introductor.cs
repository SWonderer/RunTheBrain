using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class Introductor : MonoBehaviour
{
    public List<Cell> cells;

    public Button ActBtn;
    public Button endBtn;

    public void Init()
    {
        cells = new List<Cell>();

        //������ť
        ActBtn = GameObject.Find("Introductor/ChangeBtn").GetComponent<Button>();
        endBtn = GameObject.Find("Introductor/EndBtn").GetComponent<Button>();
        ActBtn.onClick.AddListener(OnClickActBtn);
        endBtn.onClick.AddListener(OnClickEndBtn);
    }

    public void SelfDestroy()
    {
        Destroy(this.gameObject);
    }

    //�����غϰ�ť
    public void OnClickEndBtn()
    {
        if (cells[0].hasAct)
        {
            UIManager.Instance.ShowTip("��δʹ�õ��ж�ָ��", Color.red);
            return;
        }
        EnemyController.Instance.EnemyAct();
        CardController.Instance.ClearAllHandCards();
    }

    //��ʼ�ж���ť
    public void OnClickActBtn()
    {
        int manaCost = 0; //�ж�һ��������һ��Mana
        List<MoveDirection> dirs = new List<MoveDirection>();
        List<int> steps = new List<int>();
        bool canMove = true;
        for (int i = 0; i < RoleManager.Instance.mostIntrodutors; i++)
        {
            if (cells[i].dir != MoveDirection.None)
            {
                manaCost++;
                if (manaCost > PlayerController.Instance.curMana) //��Mana���� �����ж�
                {
                    UIManager.Instance.ShowTip("��������", Color.red, 1.0f);
                    canMove = false;
                    break;
                }
            }
        }

        for (int i = 0; i < RoleManager.Instance.mostIntrodutors; i++)
        {
            if (!canMove)
                return;
            if (cells[i].dir != MoveDirection.None)
            {
                //�ж��б�����
                dirs.Add(cells[i].dir);
                steps.Add(cells[i].step);
                //���ƶ����ӿ���
                CardController.Instance.usedCardList.Add(cells[i].dir.ToString() + cells[i].step.ToString() + "Card");
                //��ԭcell
                cells[i].dir = MoveDirection.None;
                cells[i].hasAct = false;
                cells[i].UpdateTxt();
                cells[i].step = 0;
            }
            if(i == RoleManager.Instance.mostIntrodutors - 1)
            {
                StopAllCoroutines();
                StartCoroutine(PlayerMove(dirs, steps));
                break;
            }
        }
        //����Mana
        PlayerController.Instance.curMana -= manaCost;
        PlayerController.Instance.UpdateMana();
    }

    IEnumerator PlayerMove(List<MoveDirection> dirs, List<int> steps)
    {
        for(int i = 0; i < dirs.Count; i++)
        {
            PlayerController.Instance.Move(dirs[i], steps[i]);
            yield return new WaitForSeconds(1.5f);
            string effName = PlayerController.Instance.GetEffName();
            Debug.Log(effName);
            if(effName == "Effect_HitEnemy")
            {
                PlayerController.Instance.Flip(0); 
                PlayerController.Instance.playerObj.GetComponent<Player>().anim.SetTrigger("atkPower1");
                yield return new WaitForSeconds(1.0f);
            }
            PlayerController.Instance.StrikeEffect();
            if (effName == "Effect_HitEnemy")
            {
                yield return new WaitForSeconds(1.3f);
            }
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
