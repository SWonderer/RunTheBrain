using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BaseEffect : MonoBehaviour
{
    //public Color fieldColor;

    //��ǰ����Ч��

    public int val;

    public string effName = "BaseEffect";

    public virtual void StrikeEffect()
    {

    }

    public void DestroyThisItem()
    {
        Destroy(this);
    }
}
