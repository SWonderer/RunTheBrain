using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class BaseLevel : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public int levelId;

    public Button selfbtn;

    public string levelKind = "BaseLevel";

    public string levelTitle;

    public string levelDes;

    private void Awake()
    {
        selfbtn = GetComponent<Button>();
        selfbtn.onClick.AddListener(OnClickLevelBtn);
    }

    public virtual void OnClickLevelBtn()
    {
        //��������UI������ս��UI
        UIManager.Instance.ClearAllUI();
        UpdateLevelId(levelId);
        UIManager.Instance.CreateFightScene();
    }

    public void UpdateLevelId(int id)
    {
        MapController.Instance.levelId = id;
        EffectController.Instance.levelId = id;
        EnemyController.Instance.levelId = id;
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        //UIManager.Instance.ShowDesContainer(new Vector2(eventData.position.x - Screen.width / 2, eventData.position.y - Screen.height / 2)
        //    , levelTitle, levelDes, Color.white);
        UIManager.Instance.ShowDesContainer(new Vector2(100, this.gameObject.GetComponent<RectTransform>().anchoredPosition.y * 0.8f)
            , levelTitle, levelDes, Color.white);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        UIManager.Instance.DestoyDesContainer();
    }

    private void OnDestroy()
    {
        UIManager.Instance.DestoyDesContainer();
    }
}
