using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LevelUI : UIBase
{
    public Button enterButton;

    public List<Button> levelList = new List<Button>();
    public List<BaseLevel> levelItemList = new List<BaseLevel>();

    public int avaLevelId = 1001;

    public List<Dictionary<string, string>> levelDataList = new List<Dictionary<string, string>>();

    public Dictionary<string, string> levelData = new Dictionary<string, string>();

    // �ж��ж��ٸ��ؿ����Կ��� �ж��ؿ����� �ڸ�����ؿ������ѡ��һЩ�ؿ�id д��name
    void Start()
    {
        levelDataList = GameConfigManager.Instance.GetLevelLines();

        //��ȡ�ؿ����
        Button[] btns = GameObject.Find("levels").GetComponentsInChildren<Button>();
        //���ؿ������б�������� 
        foreach (var btn in btns)
        {
            string levelKind = LevelManager.Instance.GetKind();
            BaseLevel levelItem;
            if (levelKind == "eliteKind" || levelKind == "normalKind")
            {
                //���һ�����ս���ؿ�id
                avaLevelId = Random.Range(1001, 1006); //range����ȡ�±�Ե���ǲ�ȡ�ϱ�Ե

                levelItem = btn.gameObject.AddComponent(System.Type.GetType("FightLevel")) as BaseLevel;
                levelItemList.Add(levelItem);
            }
            else if(levelKind == "restKind")
            {
                //���һ����Ϣ�ؿ�id
                avaLevelId = 1008; //��Ϣ�ؿ�idΪ1008

                levelItem = btn.gameObject.AddComponent(System.Type.GetType("RestLevel")) as BaseLevel;
                levelItemList.Add(levelItem);
            }
            else if(levelKind == "saloonKind")
            {
                //���һ���ƹݹؿ�id
                avaLevelId = 1009; 

                levelItem = btn.gameObject.AddComponent(System.Type.GetType("SaloonLevel")) as BaseLevel;
                levelItemList.Add(levelItem);
            }
            else
            {
                //���һ�����عؿ�id
                avaLevelId = 1010; 

                levelItem = btn.gameObject.AddComponent(System.Type.GetType("TruesureLevel")) as BaseLevel;
                levelItemList.Add(levelItem);
            }

            //�ؿ�����
            levelItem.levelKind = levelKind;

            //������
            btn.gameObject.name = avaLevelId.ToString();

            //����Ҫ�ı�ؿ����� ��Ҫ��

            levelItem.levelId = int.Parse(btn.gameObject.name);
            for(int i = 0; i < levelDataList.Count; i++)
            {
                if (levelDataList[i]["id"] == levelItem.levelId.ToString())
                {
                    levelItem.levelTitle = levelDataList[i]["title"];
                    levelItem.levelDes = levelDataList[i]["des"];
                    break;
                }
            }
            levelList.Add(btn);
        }//-----------------------------------------------------------------------------

        Init();
    }

    void Init()
    {
        //�ж��Ƿ����boss
        bool ifboss = LevelManager.Instance.ifBoss();
        //����boss�ؿ����ָ��ʣ�10��
        LevelManager.Instance.bossProAdd(10);

        //������boss ��ֻ��һ����ѡ�ؿ���Ϊboss
        if(ifboss)
        {
            for (int i = 0; i < levelItemList.Count; i++)
            {
                if (i >= 1)
                {
                    levelList[i].GetComponent<Image>().color = Color.black;
                    levelList[i].enabled = false;
                }
                else
                {
                    //���Ӷ�Ӧͼ�꣨boss��
                    GameObject icon = Instantiate(Resources.Load("UiItems/LevelIcons/bossKind")) as GameObject;
                    icon.transform.SetParent(levelItemList[i].transform);
                    icon.GetComponent<RectTransform>().anchoredPosition = Vector2.zero;
                    icon.GetComponent<RectTransform>().localScale = Vector2.one * UiFitter.ScaleFitVertical(1.5f);
                    //�޸����ֺ�levelId
                    if (levelList[i].GetComponent<FightLevel>() == null)
                    {
                        levelItemList[i].enabled = false;
                        FightLevel item = levelList[i].gameObject.AddComponent<FightLevel>();
                        item.gameObject.name = "1007";
                        item.levelId = int.Parse(item.gameObject.name);
                    }
                    else
                    {
                        levelItemList[i].gameObject.name = "1007";
                        levelItemList[i].levelId = int.Parse(levelItemList[i].gameObject.name);
                    }
                }
                LevelManager.Instance.bossPro = 0; //����boss���ֵĸ���
            }
            return;
        }

        //��ѡ�ؿ�����
        int choiceNum = LevelManager.Instance.GetChoiceNum();
        for (int i = 0; i < levelItemList.Count; i++)
        {
            if (i >= choiceNum)
            {
                levelList[i].GetComponent<Image>().color = Color.black;
                levelList[i].gameObject.SetActive(false);
                levelList[i].enabled = false;
            }
            else
            {
                //���Ӷ�Ӧͼ��
                GameObject icon = Instantiate(Resources.Load("UiItems/LevelIcons/" + levelItemList[i].levelKind)) as GameObject;
                print("levelKind:" + levelItemList[i].levelKind);
                icon.transform.SetParent(levelItemList[i].transform);
                icon.GetComponent<RectTransform>().anchoredPosition = Vector2.zero;
                icon.GetComponent<RectTransform>().localScale = Vector2.one * UiFitter.ScaleFitVertical(1.5f);
            }
        }
    }

    // Update is called once per frame
    void Update()
    {

    }
}
