using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Effect_AutoHit : BaseEffect
{
    public void Awake()
    {
        for (int i = 0; i < this.GetComponent<BaseField>().icons.Count; i++)
        {
            this.GetComponent<BaseField>().icons[i].SetActive(false);
        }
        this.GetComponent<BaseField>().AutoHitIcon.SetActive(true);
    }

    public override void StrikeEffect()
    {
        PlayerController.Instance.autoHitNum += val;
        Debug.Log("�����������Զ��������Ч��" + val);
    }
}
