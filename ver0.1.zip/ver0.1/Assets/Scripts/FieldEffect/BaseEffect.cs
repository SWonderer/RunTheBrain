using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class BaseEffect : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    //public Color fieldColor;

    //��ǰ����Ч��

    public int val;

    public string effName = "BaseEffect";

    public string effTitle;

    public string effDes;

    public virtual void StrikeEffect()
    {

    }

    public void DestroyThisItem()
    {
        Destroy(this);
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        //UIManager.Instance.ShowDesContainer(new Vector2(eventData.position.x - Screen.width / 2, eventData.position.y - Screen.height / 2)
        //    , levelTitle, levelDes, Color.white);
        StartCoroutine(LateShowDesContainer());
    }

    IEnumerator LateShowDesContainer()
    {
        UIManager.Instance.DestoyDesContainer();
        UIManager.Instance.ShowDesContainer(new Vector2(this.gameObject.GetComponent<RectTransform>().anchoredPosition.x + 100, this.gameObject.GetComponent<RectTransform>().anchoredPosition.y * 0.8f)
            , effTitle, effDes, Color.white);
        yield return null;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        UIManager.Instance.DestoyDesContainer();
    }

    private void OnDestroy()
    {
        UIManager.Instance.DestoyDesContainer();
    }
}
