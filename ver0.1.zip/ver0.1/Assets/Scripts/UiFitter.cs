using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UiFitter
{
    public static float ScaleFitHorizontal(float inputScale)
    {
        return inputScale * Screen.width / 2560.0f;
    }

    public static float ScaleFitVertical(float inputScale)
    {
        return inputScale * Screen.height / 1440.0f;
    }

    public static float PosFitHorizontal(float inputPosX)
    {
        return inputPosX * Screen.width / 2560.0f;
    }

    public static float PosFitVertical(float inputPosY)
    {
        return inputPosY * Screen.height / 1440.0f;
    }
}
