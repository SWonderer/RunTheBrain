using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Left1Card : CardItem
{
    public void Start()
    {
        dir = MoveDirection.Left;
        step = 1;
    }
}
