using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using UnityEngine.EventSystems;

public enum MoveDirection
{
    None,
    Up,
    Down,
    Left,
    Right,
}


public class PlayerController
{
    public static PlayerController Instance;

    public Vector2 playerPos;

    public GameObject playerObj;

    public Animator anim; //���ƽ�ɫ�Ķ������

    public int maxHp;

    public int curHp;

    public int shieldAmount;

    public int maxMana;

    public int curMana;

    public int strength = 0;

    public int agility = 0; //���� ��û���ʱ���õĲ���

    public int autoHitNum = 0; //ÿ�غ��Զ���������

    public int avoid_addable = 0;

    public bool avoid_unaddable = false;

    public int autoMoveWhenActStart = 0; //�غϿ�ʼ �Զ��ƶ���Ч��

    public Image hpBar;

    public Text hpTxt;

    public Text shieldTxt;

    public Text manaTxt;

    //��ʼ��
    public void Init()
    {
        strength = 0;

        agility = 0; //���� ��û���ʱ���õĲ���

        autoHitNum = 0; //ÿ�غ��Զ���������

        avoid_addable = 0;

        avoid_unaddable = false;

        autoMoveWhenActStart = 0; //�غϿ�ʼ �Զ��ƶ���Ч��

        maxHp = RoleManager.Instance.maxHp;
        curHp = RoleManager.Instance.curHp;
        maxMana = RoleManager.Instance.mana;
        curMana = maxMana;
        shieldAmount = RoleManager.Instance.shieldAmount;

        hpBar = GameObject.Find("Canvas/FightUI/hp/fill").GetComponent<Image>();
        hpTxt = GameObject.Find("Canvas/FightUI/hp/hpText").GetComponent<Text>();
        manaTxt = GameObject.Find("Canvas/FightUI/Mana/text").GetComponent<Text>();
        shieldTxt = GameObject.Find("Canvas/FightUI/hp/Shield/text").GetComponent<Text>();

        UpdateHpBar();

        UpdateMana();
    }

    //����������ʾ
    public void UpdateMana()
    {
        manaTxt.text = curMana.ToString() + "/" + maxMana.ToString();
    }

    //����Ѫ��
    public void UpdateHpBar()
    {
        hpBar.fillAmount = (float)curHp / (float)maxHp;
        hpTxt.text = curHp.ToString() + "/" + maxHp.ToString();
        shieldTxt.text = shieldAmount.ToString();
    }

    //�غϿ�ʼ �Զ�����Ч��
    public void AutoHit(int val)
    {
        if(val > 0)
            EnemyController.Instance.Hurt(val);
    }

    //����Ч�� �������ܹ���
    public void Hurt(int val)
    {
        if(avoid_unaddable)
        {
            Debug.Log("���ܣ�");
            avoid_unaddable = false;
            return;
        }
        if(avoid_addable > 0)
        {
            Debug.Log("���ܣ�");
            avoid_addable -= 1;
            return;
        }    
        shieldAmount -= val;
        UIManager.Instance.ShowRedPanel(0.2f);
        if (shieldAmount > 0)
        {
            UpdateHpBar();
            return;
        }
        else
        {
            curHp += shieldAmount;
            shieldAmount = 0;
        }
        if(curHp <= 0)
        {
            curHp = 0;
            Debug.Log("��Ϸ��������û�ˣ�");
        }
        UpdateHpBar();
    }

    //�ظ�Ѫ�� �������
    public void Heal(int val)
    {
        curHp += val;
        if (curHp > maxHp)
            curHp = maxHp;
        UpdateHpBar();
    }

    public void GetShield(int val)
    {
        shieldAmount += val;
        UpdateHpBar();
    }

    public void CreatePlayer(int primaryX, int primaryY)
    {
        //������������ ��������Ԥ����
        GameObject playerObj = GameObject.Instantiate(Resources.Load("player/Player")) as GameObject;
        //ȷ������λ�ã��ڸ��ӣ� �ҽű� ���� �㼶
        playerObj.AddComponent<Player>();
        playerObj.transform.SetParent(GameObject.Find("Canvas").transform);
        playerObj.transform.localScale = Vector3.one * UiFitter.ScaleFitHorizontal(1.5f);
        playerObj.GetComponent<RectTransform>().anchoredPosition = new Vector2(primaryX, primaryY);
        playerObj.transform.SetAsLastSibling();
        anim = playerObj.GetComponent<Animator>();
        this.playerObj = playerObj;
    }

    //��ȡ���λ��
    public void GetPlayerPos(Vector2 playerPos)
    {
        this.playerPos = playerPos;
        //Debug.Log(playerPos);
    }

    //����ƶ�����
    public void MoveToPos(Vector2 target, float duration = 0.8f, string animPara = "horiMoving")
    {
        playerObj.GetComponent<Player>().MoveToPos(target, duration, animPara);
    }

    public void MoveToPosOverMap(Vector2 target, float duration = 0.8f, MoveDirection dir = MoveDirection.Up, string animPara = "horiMoving")
    {
        playerObj.GetComponent<Player>().MoveToPosOverMap(target, duration, dir, animPara);
    }

    public void Flip(int dir) //�����ת���� 0���� 1����
    {
        if (dir == 0)
        {
            playerObj.GetComponent<RectTransform>().localRotation = Quaternion.Euler(0, 0, 0);
        }
        else if (dir == 1)
        {
            playerObj.GetComponent<RectTransform>().localRotation = Quaternion.Euler(0, 180, 0);
        }
    }

    //�ƶ�ָ�� ���뷽��Ͳ���
    public void Move(MoveDirection dir, int step)
    {
        Vector2 target = new Vector2();
        switch (dir)
        {
            case MoveDirection.Up:
                playerPos.y -= step;
                if (playerPos.y < 0)
                {
                    //��������ͼ��Χ���ƶ�����һ��
                    playerPos.y += MapController.Instance.mapHeight;

                    target = MapController.Instance.mapFields[(int)playerPos.x, (int)playerPos.y].GetComponent<RectTransform>().anchoredPosition;
                    MoveToPosOverMap(target, 0.8f, MoveDirection.Up, "upMoving");
                }
                else
                {
                    target = MapController.Instance.mapFields[(int)playerPos.x, (int)playerPos.y].GetComponent<RectTransform>().anchoredPosition;
                    MoveToPos(target, 0.8f, "upMoving");
                }
                break;
            case MoveDirection.Down:
                playerPos.y += step;
                if (playerPos.y > MapController.Instance.mapHeight - 1)
                {
                    playerPos.y -= MapController.Instance.mapHeight;

                    target = MapController.Instance.mapFields[(int)playerPos.x, (int)playerPos.y].GetComponent<RectTransform>().anchoredPosition;
                    MoveToPosOverMap(target, 0.8f, MoveDirection.Down, "downMoving");
                }
                else
                {
                    target = MapController.Instance.mapFields[(int)playerPos.x, (int)playerPos.y].GetComponent<RectTransform>().anchoredPosition;
                    MoveToPos(target, 0.8f, "downMoving");
                }
                break;
            case MoveDirection.Left:
                Flip(1); //����ת
                playerPos.x -= step;
                if (playerPos.x < 0)
                {
                    playerPos.x += MapController.Instance.mapWidth;

                    target = MapController.Instance.mapFields[(int)playerPos.x, (int)playerPos.y].GetComponent<RectTransform>().anchoredPosition;
                    MoveToPosOverMap(target, 0.8f, MoveDirection.Left);
                }
                else
                {
                    target = MapController.Instance.mapFields[(int)playerPos.x, (int)playerPos.y].GetComponent<RectTransform>().anchoredPosition;
                    MoveToPos(target);
                }
                break;
            case MoveDirection.Right:
                Flip(0); //���ҷ�ת
                playerPos.x += step;
                if (playerPos.x > MapController.Instance.mapWidth - 1)
                {
                    playerPos.x -= MapController.Instance.mapWidth;

                    target = MapController.Instance.mapFields[(int)playerPos.x, (int)playerPos.y].GetComponent<RectTransform>().anchoredPosition;
                    MoveToPosOverMap(target, 0.8f, MoveDirection.Right);
                }
                else
                {
                    target = MapController.Instance.mapFields[(int)playerPos.x, (int)playerPos.y].GetComponent<RectTransform>().anchoredPosition;
                    MoveToPos(target);
                }
                break;
            default:
                break;
        }
    }

    //�������� (ÿ�غϿ�ʼ)
    public void ResetMana()
    {
        curMana = maxMana;
        UpdateMana();
    }

    public void PlayerActStart()
    {
        UIManager.Instance.ShowTip("�ҷ��غ�", Color.blue, 1.0f);
        EffectController.Instance.Refesh();
        IntroductorController.Instance.fightUnit = FightUnit.PlayerTurn;
        if(autoMoveWhenActStart > 0)
        {
            AutoMoveWhenActStart();
            autoMoveWhenActStart -= 1;
        }
        if(autoHitNum > 0)
            AutoHit(autoHitNum);
        ResetMana();
        Debug.Log(IntroductorController.Instance.fightUnit.ToString());
        if(RoleManager.Instance.ready)
        {
            CardController.Instance.DrawCard(10);
            RoleManager.Instance.ready = false;
        }
        else
            CardController.Instance.DrawCard(4);
        CardController.Instance.CreateHandCards();
    }

    //�غϿ�ʼʱ�Զ��ƶ�Ч��
    public void AutoMoveWhenActStart()
    {
        Move(GetRandDir(), GetRandSteps(1, 2));
        string effName = GetEffName();
        playerObj.GetComponent<Player>().LateStrikeEff(1.0f, effName);
    }

    //��ȡ�������
    public MoveDirection GetRandDir()
    {
        MoveDirection dir = MoveDirection.None;
        switch (Random.Range(1, 4))
        {
            case 1:
                dir = MoveDirection.Up;
                break;
            case 2:
                dir = MoveDirection.Down;
                break;
            case 3:
                dir = MoveDirection.Left;
                break;
            case 4:
                dir = MoveDirection.Right;
                break;
            default:
                break;
        }
        return dir;
    }

    //��ȡ�������
    public int GetRandSteps(int minStep, int maxStep)
    {
        return Random.Range(minStep, maxStep);
    }

    //��Ҵ������¸��ӵ�Ч��
    public string StrikeEffect()
    {
        BaseEffect effectItem = MapController.Instance.mapFields[(int)playerPos.x, (int)playerPos.y].
            GetComponent(System.Type.GetType("BaseEffect")) as BaseEffect;
        if(effectItem != null)
        {
            effectItem.StrikeEffect();
            Debug.Log("Ч���Ѵ�����");
            return effectItem.effName;
        }
        return null;
    }

    public string GetEffName()
    {
        BaseEffect effectItem = MapController.Instance.mapFields[(int)playerPos.x, (int)playerPos.y].
            GetComponent(System.Type.GetType("BaseEffect")) as BaseEffect;
        if (effectItem != null)
        {
            return effectItem.effName;
        }
        return null;
    }

    public void ClearPlayerObj()
    {
        playerObj.GetComponent<Player>().SelfDestroy();
    }
}
