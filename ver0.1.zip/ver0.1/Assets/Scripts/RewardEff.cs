using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// �����ڽ���Ч����
/// </summary>
public class RewardEff : MonoBehaviour
{
    public Button ReBtn;

    void Awake()
    {
        ReBtn = GetComponentInChildren<Button>();
        ReBtn.onClick.AddListener(OnClickThisBtn);
    }

    public void OnClickThisBtn()
    {
        EndBattlePanel.Instance.ClearAllEffRewards();
        RoleManager.Instance.fieldEffects += "," + GameObject.Find(this.gameObject.name + "/BackGround").GetComponentInChildren<NameTagger>().nameTag;
    }

    public void SelfDestory()
    {
        Destroy(this.gameObject);
    }
}
