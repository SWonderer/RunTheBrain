using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Cell : MonoBehaviour
{
    public bool isValid; //�Ƿ��ܱ�ʹ��

    public bool hasAct; //�Ƿ��Ѿ����ж�

    public Text cellTxt;

    public MoveDirection dir;
    public int step = 0;

    public int index; //��Introductor�е�˳��

    public void Init()
    {
        dir = MoveDirection.None;
        cellTxt = GetComponentInChildren<Text>();
        if(!isValid)
        {
            cellTxt.text = "�޷�ʹ��";
        }
        else
        {
            cellTxt.text = "";
        }
        index = (int)this.transform.name.Substring(4)[0] - 48;
        Button btn = this.gameObject.AddComponent<Button>();
        btn.onClick.AddListener(OnClickCellBtn);
    }

    //����cell �������� ɾ��cell��Ϣ
    public void OnClickCellBtn()
    {
        CardController.Instance.CreateCardByPos(dir.ToString() + step.ToString() + "Card", this.GetComponent<RectTransform>().anchoredPosition + 
            new Vector2(Screen.width / 2, Screen.height / 2));
        RemoveThisCell();
        IntroductorController.Instance.UpdateAllValidTxt();
    }

    //ɾ��cell�е����� ����һ��cell���
    public void RemoveThisCell()
    {
        for(int i = index; i < RoleManager.Instance.mostIntrodutors; i++)
        {
            if(!isValid)
            {
                break;
            }
            if(i == IntroductorController.Instance.cells.Count - 1)
            {
                IntroductorController.Instance.cells[i].dir = MoveDirection.None;
                IntroductorController.Instance.cells[i].step = 0;
                IntroductorController.Instance.cells[i].hasAct = false;
                break;
            }
            IntroductorController.Instance.cells[i].dir = IntroductorController.Instance.cells[i + 1].dir;
            IntroductorController.Instance.cells[i].step = IntroductorController.Instance.cells[i + 1].step;
            IntroductorController.Instance.cells[i].hasAct = IntroductorController.Instance.cells[i + 1].hasAct;
        }
    }

    //��������
    public void UpdateTxt()
    {
        switch (dir)
        {
            case MoveDirection.Up:
                cellTxt.text = "��" + step.ToString();
                break;
            case MoveDirection.Down:
                cellTxt.text = "��" + step.ToString();
                break;
            case MoveDirection.Right:
                cellTxt.text = "��" + step.ToString();
                break;
            case MoveDirection.Left:
                cellTxt.text = "��" + step.ToString();
                break;
            case MoveDirection.None:
                cellTxt.text = "";
                break;
            default:
                break;
        }

    }

    public void Awake()
    {

    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        this.GetComponent<Button>().enabled = hasAct;
    }
}
