using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// �����ļ�������
/// </summary>
public class GameConfigManager
{
    public static GameConfigManager Instance = new GameConfigManager();

    public GameConfig CardConfig;

    public GameConfig EnemyConfig;

    public GameConfig LevelConfig;

    public GameConfig EffectConfig;

    public GameConfig EnemyActConfig;

    public TextAsset textAsset;

    public void Init()
    {
        //���뿨�������ļ�
        textAsset = Resources.Load<TextAsset>("Data/card");
        CardConfig = new GameConfig(textAsset.text);
        //����ؿ������ļ�
        textAsset = Resources.Load<TextAsset>("Data/level");
        LevelConfig = new GameConfig(textAsset.text);
        //������������ļ�
        textAsset = Resources.Load<TextAsset>("Data/enemy");
        EnemyConfig = new GameConfig(textAsset.text);
        //����Ч�������ļ�
        textAsset = Resources.Load<TextAsset>("Data/effect");
        EffectConfig = new GameConfig(textAsset.text);
        //���������Ϊ�ļ�
        textAsset = Resources.Load<TextAsset>("Data/enemyAct");
        EnemyActConfig = new GameConfig(textAsset.text);
    }
    
    public List<Dictionary<string, string>> GetCardLines()
    {
        return CardConfig.GetLines();
    }

    public List<Dictionary<string, string>> GetLevelLines()
    {
        return LevelConfig.GetLines();
    }

    public List<Dictionary<string, string>> GetEnemyLines()
    {
        return EnemyConfig.GetLines();
    }

    public List<Dictionary<string, string>> GetEffectLines()
    {
        return EffectConfig.GetLines();
    }

    public List<Dictionary<string, string>> GetEnemyActLines()
    {
        return EnemyActConfig.GetLines();
    }

    public Dictionary<string, string> GetCardById(string id)
    {
        return CardConfig.GetLinesById(id);
    }

    public Dictionary<string, string> GetLevelById(string id)
    {
        return LevelConfig.GetLinesById(id);
    }

    public Dictionary<string, string> GetEnemyById(string id)
    {
        return EnemyConfig.GetLinesById(id);
    }

    public Dictionary<string, string> GetEffectById(string id)
    {
        return EffectConfig.GetLinesById(id);
    }

    public Dictionary<string, string> GetEnemyActById(string id)
    {
        return EnemyActConfig.GetLinesById(id);
    }
}
