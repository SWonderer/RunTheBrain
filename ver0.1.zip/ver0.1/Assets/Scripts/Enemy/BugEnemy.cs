using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BugEnemy : EnemyBase
{
    public override void Awake()
    {
        maxHp = 3;
        shieldAmount = 0;
        base.Awake();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
