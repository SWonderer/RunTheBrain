using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

/// <summary>
/// ���˿�����
/// ���ɵ��� ��������͵�ͼ�ϵĵ���
/// ȷ��������ֵ ʹ��EnemyBase����ű���� ֱ�ӹ���EnemyBase�ű�����
/// ������Ϊ�߼�
/// </summary>
public class EnemyController
{
    public static EnemyController Instance;

    public int maxHp;

    public int curHp;

    public int shieldAmount;

    public bool isDead = false;

    public GameObject EnemyObj;

    public EnemyBase EnemyItem;

    public Image hpBar;

    public Text hpTxt;

    public Text shieldTxt;

    public List<string> enemyAct;

    public Dictionary<string, string> enemyData;

    public int levelId;

    //��ʼ��
    public void Init()
    {
        isDead = false;

        string enemyId = GameConfigManager.Instance.GetLevelById(levelId.ToString())["EnemyId"];
        enemyData = GameConfigManager.Instance.GetEnemyById(enemyId);

        enemyAct = new List<string>();

        //���ӵ����ж�����
        string[] tempList = enemyData["ActList"].Trim().Split(",");
        foreach (var str in tempList)
        {
            Debug.Log(str);
            enemyAct.Add(str);
        }
        GameObject enemyObj = GameObject.Instantiate(Resources.Load("Enemy/" + enemyData["EnemyName"])) as GameObject;
        //������ ���Ӽ� λ��
        enemyObj.transform.name = enemyData["EnemyName"];
        enemyObj.transform.SetParent(GameObject.Find("Canvas/Enemy").transform);
        enemyObj.transform.localScale = Vector3.one * UiFitter.ScaleFitHorizontal(1);
        enemyObj.GetComponent<RectTransform>().anchoredPosition = Vector2.zero;
        //���ؽű�
        EnemyBase enemyItem = enemyObj.AddComponent(System.Type.GetType(enemyObj.transform.name)) as EnemyBase;
        //��ʾ�㼶
        enemyObj.transform.SetAsLastSibling();
        //��ʼ��Ѫ��
        enemyItem.maxHp = int.Parse(enemyData["MaxHp"]);
        maxHp = enemyItem.maxHp;
        curHp = maxHp;
        //��ǰ�ű���ȡ��������
        this.EnemyObj = enemyObj;
        this.EnemyItem = enemyItem;

        shieldAmount = enemyItem.shieldAmount;
        maxHp = enemyItem.maxHp;
        curHp = maxHp;

        //UI�����ȡ
        hpBar = GameObject.Find("Canvas/FightUI/enemyHp/fill").GetComponent<Image>();
        hpTxt = GameObject.Find("Canvas/FightUI/enemyHp/hpText").GetComponent<Text>();
        shieldTxt = GameObject.Find("Canvas/FightUI/enemyHp/Shield/text").GetComponent<Text>();

        UpdateHpBar();
        canHurt = true;
    }

    public void ClearEnemy()
    {
        EnemyObj.GetComponent<EnemyBase>().SelfDestroy();
    }

    bool canHurt = true;

    public void Hurt(int val)
    {
        if (!canHurt)
            return;
        if(EnemyObj.GetComponent<EnemyBase>().spikeVal > 0) //���˷���
        {
            PlayerController.Instance.Hurt(EnemyObj.GetComponent<EnemyBase>().spikeVal);
        }
        if(EnemyItem.GetComponent<EnemyBase>().protectVal > 0) //�˺�����
        {
            val /= 2;
            EnemyItem.GetComponent<EnemyBase>().protectVal -= 1;
        }
        shieldAmount -= val;
        EnemyItem.HurtEffect();
        if (shieldAmount > 0)
        {
            UpdateHpBar();
            return;
        }
        else
        {
            curHp += shieldAmount;
            shieldAmount = 0;
        }
        if (curHp <= 0)
        {
            curHp = 0;
            UIManager.Instance.ShowEndBattlePanel("��ʤ���ˣ�", Color.red);
            isDead = true;
            canHurt = false;
        }
        UpdateHpBar();
    }

    public void UpdateHpBar()
    {
        hpBar.fillAmount = (float)curHp / (float)maxHp;
        hpTxt.text = curHp.ToString() + "/" + maxHp.ToString();
        shieldTxt.text = shieldAmount.ToString();
    }

    public void EnemyAct()
    {
        if (isDead)
            return;
        IntroductorController.Instance.fightUnit = FightUnit.EnemyTurn;
        UIManager.Instance.ShowTip("���˻غ�", Color.red, 1.0f);
        Debug.Log(IntroductorController.Instance.fightUnit.ToString());
        EnemyItem.EnemyAct();
    }

    public void Hit(int val)
    {
        val += EnemyObj.GetComponent<EnemyBase>().enhanceVal;
        if(EnemyObj.GetComponent<EnemyBase>().criticalVal > 0)
        {
            val *= 2;
            EnemyObj.GetComponent<EnemyBase>().criticalVal -= 1;
        }
        PlayerController.Instance.Hurt(val);
    }

    public void GetShield(int val)
    {
        val += EnemyObj.GetComponent<EnemyBase>().enhanceVal;
        shieldAmount += val;
        UpdateHpBar();
    }

    public void Enhance(int val) //����ս���й����ͻ�������val
    {
        EnemyObj.GetComponent<EnemyBase>().enhanceVal += val;
    }

    public void Critical(int val) //��val�ι���˫���˺�
    {
        EnemyObj.GetComponent<EnemyBase>().criticalVal += val;
    }

    public void Spike(int val) //�����Զ������˺�
    {
        EnemyObj.GetComponent<EnemyBase>().spikeVal += val;
    }

    public void Protect(int val) //����һ���˺�
    {
        EnemyObj.GetComponent<EnemyBase>().protectVal += val;
    }
}
