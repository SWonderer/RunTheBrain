using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Down0Card : CardItem
{
    public void Start()
    {
        dir = MoveDirection.Down;
        step = 0;
    }
}
