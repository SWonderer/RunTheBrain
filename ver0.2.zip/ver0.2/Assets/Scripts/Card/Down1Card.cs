using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Down1Card : CardItem
{
    public void Start()
    {
        dir = MoveDirection.Down;
        step = 1;
    }
}
