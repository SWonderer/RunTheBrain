using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using DG.Tweening;

public class EnemyBase : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public int maxHp;

    public int shieldAmount;

    private int actCount = 1;

    public int value;

    public int atkWeakVal = 0;

    public int enhanceVal = 0; //���ܺ��˺���ǿ����ֵ

    public int criticalVal = 0; //˫���˺��Ĵ���

    public int spikeVal = 0; //�Զ������˺�

    public int protectVal = 0; //����һ���˺�����

    public Dictionary<GameObject, bool> showIconDic = new Dictionary<GameObject, bool>();

    public List<Dictionary<string, string>> enemyActDataList = new List<Dictionary<string, string>>();

    public GameObject HitIcon;
    public GameObject GetShieldIcon;
    public GameObject OtherIcon;
    public GameObject EnhanceIcon;
    public GameObject CriticalIcon;
    public GameObject SpikeIcon;
    public GameObject ProtectIcon;

    public virtual void Awake()
    {
        HitIcon = GameObject.Find("ActIcons/Hit");
        GetShieldIcon = GameObject.Find("ActIcons/GetShield");
        OtherIcon = GameObject.Find("ActIcons/Other");
        EnhanceIcon = GameObject.Find("ActIcons/Enhance");
        CriticalIcon = GameObject.Find("ActIcons/Critical");
        SpikeIcon = GameObject.Find("ActIcons/Spike");
        ProtectIcon = GameObject.Find("ActIcons/Protect");

        enemyActDataList = GameConfigManager.Instance.GetEnemyActLines();

        InitActIconAct();

        //��ȡ�ж��б�
        List<string> actList = new List<string>();
        List<string> numList = new List<string>();
        char c;
        char c1 = 'a';
        string act = "";
        string num = "";
        for (int i = 0; i < EnemyController.Instance.enemyAct[actCount - 1].Length; i++)
        {
            int n = 0;
            c = EnemyController.Instance.enemyAct[actCount - 1][i];
            if (!isNum(c.ToString(), n))
            {
                act += c;
            }
            else
            {
                num += c;
            }
            if (!isNum(c1.ToString(), n) && isNum(c.ToString(), n))
            {
                actList.Add(act);
                act = "";
            }
            if (isNum(c1.ToString(), n) && !isNum(c.ToString(), n))
            {
                numList.Add(num);
                num = "";
            }
            c1 = c;
            if (i == EnemyController.Instance.enemyAct[actCount - 1].Length - 1)
            {
                numList.Add(num);
            }
        }
        //ʹ��ActList�е����ݸ���showIconDic������
        foreach (var item in actList)
        {
            switch (item)
            {
                case "Hit":
                    showIconDic[HitIcon] = true;
                    break;
                case "GetShield":
                    showIconDic[GetShieldIcon] = true;
                    break;
                case "Other":
                    showIconDic[OtherIcon] = true;
                    break;
                case "Enhance":
                    showIconDic[EnhanceIcon] = true;
                    break;
                case "Critical":
                    showIconDic[CriticalIcon] = true;
                    break;
                case "Spike":
                    showIconDic[SpikeIcon] = true;
                    break;
                case "Protect":
                    showIconDic[ProtectIcon] = true;
                    break;
                default:
                    break;
            }
        }
        UpdateActIcon();
    }

    public void InitActIconAct()
    {
        showIconDic.Add(HitIcon, false);
        showIconDic.Add(GetShieldIcon, false);
        showIconDic.Add(OtherIcon, false);
        showIconDic.Add(EnhanceIcon, false);
        showIconDic.Add(CriticalIcon, false);
        showIconDic.Add(SpikeIcon, false);
        showIconDic.Add(ProtectIcon, false);
    }

    // Start is called before the first frame update
    void Start()
    {

    }

    //�����ж���ͼ
    void UpdateActIcon()
    {
        foreach(var item in showIconDic)
        {
            item.Key.SetActive(item.Value);
        }    
    }

    public void ResetActIconDic()
    {
        showIconDic[HitIcon] = false;
        showIconDic[GetShieldIcon] = false;
        showIconDic[OtherIcon] = false;
        showIconDic[EnhanceIcon] = false;
        showIconDic[CriticalIcon] = false;
        showIconDic[SpikeIcon] = false;
        showIconDic[ProtectIcon] = false;
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void SelfDestroy()
    {
        Destroy(this.gameObject);
    }

    public void EnemyAct()
    {
        StopAllCoroutines();
        StartCoroutine(enemyTurn());
    }

    //�ܻ�Ч��
    public void HurtEffect()
    {
        this.gameObject.transform.DOShakePosition(0.2f, 10, 10, 150);
        StartCoroutine(HurtColor());
    }

    IEnumerator HurtColor()
    {
        this.gameObject.GetComponent<Image>().color = Color.red;
        yield return new WaitForSeconds(0.2f);
        this.gameObject.GetComponent<Image>().color = Color.white;
    }

    IEnumerator enemyTurn()
    {
        yield return new WaitForSeconds(1.0f);
        print("�����ж����кţ�" + actCount);
        List<string> actList = new List<string>();
        List<string> numList = new List<string>();
        char c;
        char c1 = 'a';
        string act = "";
        string num = "";
        for (int i = 0; i < EnemyController.Instance.enemyAct[actCount - 1].Length; i++)
        {
            int n = 0;
            c = EnemyController.Instance.enemyAct[actCount - 1][i];
            if(!isNum(c.ToString(), n))
            {
                act += c;
            }
            else
            {
                num += c;
                print("c:" + c);
            }
            if(!isNum(c1.ToString(), n) && isNum(c.ToString(), n))
            {
                actList.Add(act);
                act = "";
            }
            if(isNum(c1.ToString(), n) && !isNum(c.ToString(), n))
            {
                numList.Add(num);
                num = "";
            }
            c1 = c;
            if (i == EnemyController.Instance.enemyAct[actCount - 1].Length - 1)
            {
                numList.Add(num);
            }
        }
        //ִ���ж�
        for (int i = 0; i < actList.Count; i++)
        {
            value = int.Parse(numList[i]);
            if(atkWeakVal > 0 && actList[i] == "Hit") //�����������ҵ�ǰ�ж�Ϊ����
            {
                value -= atkWeakVal;
                atkWeakVal -= 1; //��������������ÿһ��ʹ�����˺�����1������ÿ����һ��������������1
            }
            Invoke(actList[i], 0);
            print("�����ж���" + actList[i] + numList[i]);
            yield return new WaitForSeconds(0.2f);
        }
        ResetActIconDic();
        //������һ�ε����ж�
        actCount++;
        if (actCount > EnemyController.Instance.enemyAct.Count)
            actCount %= EnemyController.Instance.enemyAct.Count;

        actList.Clear();
        numList.Clear();

        //��ȡ�ж�
        for (int i = 0; i < EnemyController.Instance.enemyAct[actCount - 1].Length; i++)
        {
            int n = 0;
            c = EnemyController.Instance.enemyAct[actCount - 1][i];
            if (!isNum(c.ToString(), n))
            {
                act += c;
            }
            else
            {
                num += c;
            }
            if (!isNum(c1.ToString(), n) && isNum(c.ToString(), n))
            {
                actList.Add(act);
                act = "";
            }
            if (isNum(c1.ToString(), n) && !isNum(c.ToString(), n))
            {
                numList.Add(num);
                num = "";
            }
            c1 = c;
            if (i == EnemyController.Instance.enemyAct[actCount - 1].Length - 1)
            {
                numList.Add(num);
            }
        }
        //ʹ��ActList�е����ݸ���showIconDic������
        foreach (var item in actList)
        {
            switch (item)
            {
                case "Hit":
                    showIconDic[HitIcon] = true;
                    break;
                case "GetShield":
                    showIconDic[GetShieldIcon] = true;
                    break;
                case "Other":
                    showIconDic[OtherIcon] = true;
                    break;
                case "Enhance":
                    showIconDic[EnhanceIcon] = true;
                    break;
                case "Critical":
                    showIconDic[CriticalIcon] = true;
                    break;
                case "Spike":
                    showIconDic[SpikeIcon] = true;
                    break;
                case "Protect":
                    showIconDic[ProtectIcon] = true;
                    break;
                default:
                    break;
            }
        }
        UpdateActIcon();
        yield return new WaitForSeconds(2.5f);
        PlayerController.Instance.PlayerActStart();
    }

    public bool isNum(string s, int re)
    {
        bool isnum = false;
        isnum = int.TryParse(s, out re);
        return isnum;
    }

    public void Hit()
    {
        EnemyController.Instance.Hit(value);
    }

    public void GetShield()
    {
        EnemyController.Instance.GetShield(value);
    }

    public void Enhance()
    {
        EnemyController.Instance.Enhance(value);
    }

    public void Critical()
    {
        EnemyController.Instance.Critical(value);
    }

    public void Spike()
    {
        EnemyController.Instance.Spike(value);
    }

    public void Protect()
    {
        EnemyController.Instance.Protect(value);
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        UIManager.Instance.DestoyAllDesContainer();
        int count = 0;
        foreach (var item in showIconDic)
        {
            if (item.Value == true)
            {
                for (int i = 0; i < enemyActDataList.Count; i++)
                {
                    if (enemyActDataList[i]["actName"] == item.Key.gameObject.name)
                    {
                        UIManager.Instance.ShowDesContainer(this.gameObject.GetComponent<RectTransform>().anchoredPosition + new Vector2(200, -count * 300) + new Vector2(-850, 160),
                            enemyActDataList[i]["title"], enemyActDataList[i]["des"], Color.white, "DesContainer" + count);
                    }
                }
                count++;
            }
        }
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        UIManager.Instance.DestoyAllDesContainer();
    }

    private void OnDestroy()
    {
        UIManager.Instance.DestoyAllDesContainer();
    }

}
