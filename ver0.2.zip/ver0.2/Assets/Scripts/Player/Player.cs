using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//�������������ϵĽű�
public class Player : MonoBehaviour
{
    public Animator anim; //�����������

    public void Awake()
    {
        anim = GetComponent<Animator>();
    }

    public void SelfDestroy()
    {
        Destroy(this.gameObject);
    }

    public void MoveToPos(Vector2 pos, float duration = 1.0f, string animPara = "horiMoving")
    {
        StopAllCoroutines();
        StartCoroutine(moveToPos(pos, duration, animPara));
    }

    public void MoveToPosOverMap(Vector2 pos, float duration = 1.0f, MoveDirection dir = MoveDirection.Up, string animPara = "horiMoving")
    {
        StopAllCoroutines();
        StartCoroutine(moveToPosOverMap(pos, duration, dir, animPara));
    }

    IEnumerator moveToPos(Vector2 pos, float duration = 1.0f, string animPara = "horiMoving")
    {
        Vector2 vec = pos - this.gameObject.GetComponent<RectTransform>().anchoredPosition;
        Vector2 perVec = vec / (duration / 0.01f);
        anim.SetBool(animPara, true);
        while ((this.gameObject.GetComponent<RectTransform>().anchoredPosition - pos).magnitude > 3.0f)
        {
            this.gameObject.GetComponent<RectTransform>().anchoredPosition += perVec;
            yield return new WaitForSeconds(0.01f);
        }
        SetAllAnimPara(false);
        yield return null;
    }

    IEnumerator moveToPosOverMap(Vector2 pos, float duration = 1.0f, MoveDirection dir = MoveDirection.Up, string animPara = "horiMoving")
    {
        Vector2 target = new Vector2();
        Vector2 vec = new Vector2();
        Vector2 perVec = new Vector2();
        anim.SetBool(animPara, true);
        switch (dir)
        {
            case MoveDirection.Up:
                //��������ͼ��Χ���ƶ�����һ��
                target = new Vector2(PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition.x,
                    MapController.Instance.mapHeight * 110); //�ƶ�����ͼ����
                //target = PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition + new Vector2(0, 110); //�ƶ�����ͼ����
                vec = target - PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition;
                perVec = vec / (duration / 0.02f); //ÿ��ѭ���ƶ��ľ���
                while ((PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition - target).magnitude > 3.0f)
                {
                    PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition += perVec;
                    yield return new WaitForSeconds(0.01f);
                }

                target = pos - new Vector2(0, 110); //˲���ƶ���Ŀ���ͼ����
                PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition = target;

                target = pos;
                vec = target - PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition;
                perVec = vec / (duration / 0.02f); //ÿ��ѭ���ƶ��ľ���
                while ((PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition - target).magnitude > 3.0f)
                {
                    PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition += perVec;
                    yield return new WaitForSeconds(0.01f);
                }
                break;
            case MoveDirection.Down:
                //��������ͼ��Χ���ƶ�����һ��
                target = new Vector2(PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition.x,
                    -MapController.Instance.mapHeight * 110); //�ƶ�����ͼ����
                //target = PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition - new Vector2(0, 110); //�ƶ�����ͼ����
                vec = target - PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition;
                perVec = vec / (duration / 0.02f); //ÿ��ѭ���ƶ��ľ���
                while ((PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition - target).magnitude > 3.0f)
                {
                    PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition += perVec;
                    yield return new WaitForSeconds(0.01f);
                }

                target = pos + new Vector2(0, 110); //˲���ƶ���Ŀ���ͼ����
                PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition = target;

                target = pos;
                vec = target - PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition;
                perVec = vec / (duration / 0.02f); //ÿ��ѭ���ƶ��ľ���
                while ((PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition - target).magnitude > 3.0f)
                {
                    PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition += perVec;
                    yield return new WaitForSeconds(0.01f);
                }
                break;
            case MoveDirection.Left:
                //��������ͼ��Χ���ƶ�����һ��
                target = new Vector2(-MapController.Instance.mapWidth * 110, 
                    PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition.y); //�ƶ�����ͼ����
                //target = PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition - new Vector2(110, 0); //�ƶ�����ͼ����
                vec = target - PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition;
                perVec = vec / (duration / 0.02f); //ÿ��ѭ���ƶ��ľ���
                while ((PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition - target).magnitude > 3.0f)
                {
                    PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition += perVec;
                    yield return new WaitForSeconds(0.01f);
                }

                target = pos + new Vector2(110, 0); //˲���ƶ���Ŀ���ͼ����
                PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition = target;

                target = pos;
                vec = target - PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition;
                perVec = vec / (duration / 0.02f); //ÿ��ѭ���ƶ��ľ���
                while ((PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition - target).magnitude > 3.0f)
                {
                    PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition += perVec;
                    yield return new WaitForSeconds(0.01f);
                }
                break;
            case MoveDirection.Right:
                //��������ͼ��Χ���ƶ�����һ��
                target = new Vector2(MapController.Instance.mapWidth * 110,
                    PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition.y); //�ƶ�����ͼ����
                //target = PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition + new Vector2(110, 0); //�ƶ�����ͼ����
                vec = target - PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition;
                perVec = vec / (duration / 0.02f); //ÿ��ѭ���ƶ��ľ���
                while ((PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition - target).magnitude > 3.0f)
                {
                    PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition += perVec;
                    yield return new WaitForSeconds(0.01f);
                }

                target = pos - new Vector2(110, 0); //˲���ƶ���Ŀ���ͼ����
                PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition = target;

                target = pos;
                vec = target - PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition;
                perVec = vec / (duration / 0.02f); //ÿ��ѭ���ƶ��ľ���
                while ((PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition - target).magnitude > 3.0f)
                {
                    PlayerController.Instance.playerObj.GetComponent<RectTransform>().anchoredPosition += perVec;
                    yield return new WaitForSeconds(0.01f);
                }
                break;
            default:
                break;
        }
        SetAllAnimPara(false);
        yield return null;
    }

    public void LateStrikeEff(float waitTime, string effName)
    {
        StartCoroutine(LateStrike(waitTime, effName));
    }

    IEnumerator LateStrike(float waitTime, string effName)
    {
        yield return new WaitForSeconds(1.5f);
        if (effName == "Effect_HitEnemy")
        {   
            PlayerController.Instance.Flip(0);
            PlayerController.Instance.playerObj.GetComponent<Player>().anim.SetTrigger("atkPower1");
            yield return new WaitForSeconds(1.0f);
        }
        PlayerController.Instance.StrikeEffect();
        if (effName == "Effect_HitEnemy")
        {
            yield return new WaitForSeconds(1.3f);
        }
    }

    //ÿ�����Ӷ���ʱ���ע��ú���������
    public void SetAllAnimPara(bool flag = false)
    {
        anim.SetBool("horiMoving", flag);
        anim.SetBool("downMoving", flag);
        anim.SetBool("upMoving", flag);
    }

    public void Update()
    {
        //������ģʽ ��ո�����20���˺�
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (EnemyController.Instance != null)
                EnemyController.Instance.Hurt(20);
        }
    }
}
