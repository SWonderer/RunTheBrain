using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RestUI : UIBase
{
    public Button TakeABreakBtn;
    public Button BeReadyBtn;

    public void Awake()
    {
        TakeABreakBtn = GameObject.Find("TakeABreakBtn").GetComponent<Button>();
        TakeABreakBtn.onClick.AddListener(OnClickTakeABreakBtn);
        BeReadyBtn = GameObject.Find("BeReadyBtn").GetComponent<Button>();
        BeReadyBtn.onClick.AddListener(OnClickBeReadyBtn);
    }

    public void OnClickTakeABreakBtn()
    {
        RoleManager.Instance.curHp += (int)(RoleManager.Instance.maxHp * 0.4f);
        if(RoleManager.Instance.curHp > RoleManager.Instance.maxHp)
            RoleManager.Instance.curHp = RoleManager.Instance.maxHp;
        UIManager.Instance.ClearAllUI();
        UIManager.Instance.CreateUIByName("LevelUI");
    }

    public void OnClickBeReadyBtn()
    {
        RoleManager.Instance.ready = true;
        UIManager.Instance.ClearAllUI();
        UIManager.Instance.CreateUIByName("LevelUI");
    }
}
