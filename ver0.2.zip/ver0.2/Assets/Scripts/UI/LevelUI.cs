using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LevelUI : UIBase
{
    public Button enterButton;

    public List<Button> levelList = new List<Button>();
    public List<BaseLevel> levelItemList = new List<BaseLevel>();

    public int avaLevelId = 1001;

    public List<Dictionary<string, string>> levelDataList = new List<Dictionary<string, string>>();

    public Dictionary<string, string> levelData = new Dictionary<string, string>();

    public int curLevel;

    public int curStage;

    // �ж��ж��ٸ��ؿ����Կ��� �ж��ؿ����� �ڸ�����ؿ������ѡ��һЩ�ؿ�id д��name
    void Start()
    {
        levelDataList = GameConfigManager.Instance.GetLevelLines();

        RoleManager.Instance.AddCurLevel(1);

        //��ȡ��ǰ�ؿ�
        curLevel = RoleManager.Instance.GetCurLevel();

        //��ȡ��ǰ����
        curStage = RoleManager.Instance.GetCurStage();

        //��ȡ�ؿ����
        Button[] btns = GameObject.Find("levels").GetComponentsInChildren<Button>();
        //���ؿ������б�������� 
        foreach (var btn in btns)
        {
            string levelKind = LevelManager.Instance.GetKind();
            BaseLevel levelItem;
            if (levelKind == "normalKind")
            {
                if(curStage == 1) //��ǰ���ڵ�һ��
                {
                    if (curLevel < 3) //�����ǰ���ڵ�һ���ǰ���� ���������ֳ�
                    {
                        //���һ�����ս���ؿ�id
                        avaLevelId = Random.Range(1001, 1004); //range����ȡ�±�Ե���ǲ�ȡ�ϱ�Ե
                    }
                    else
                    {
                        //���һ�����ս���ؿ�id
                        avaLevelId = Random.Range(1004, 1010); //range����ȡ�±�Ե���ǲ�ȡ�ϱ�Ե
                    }
                }
                else if(curStage == 2)
                {
                    //���һ�����ս���ؿ�id
                    avaLevelId = Random.Range(1016, 1021); //range����ȡ�±�Ե���ǲ�ȡ�ϱ�Ե
                }

                levelItem = btn.gameObject.AddComponent(System.Type.GetType("FightLevel")) as BaseLevel;
                levelItemList.Add(levelItem);
            }
            else if(levelKind == "eliteKind")
            {
                if(curStage == 1)
                {
                    //���һ�����ս���ؿ�id
                    avaLevelId = Random.Range(1010, 1012); //range����ȡ�±�Ե���ǲ�ȡ�ϱ�Ե
                }
                else if(curStage == 2)
                {
                    //���һ�����ս���ؿ�id
                    avaLevelId = Random.Range(1021, 1024); //range����ȡ�±�Ե���ǲ�ȡ�ϱ�Ե
                }

                levelItem = btn.gameObject.AddComponent(System.Type.GetType("FightLevel")) as BaseLevel;
                levelItemList.Add(levelItem);
            }
            else if(levelKind == "restKind")
            {
                //���һ����Ϣ�ؿ�id
                avaLevelId = 1013; //��Ϣ�ؿ�idΪ1013

                levelItem = btn.gameObject.AddComponent(System.Type.GetType("RestLevel")) as BaseLevel;
                levelItemList.Add(levelItem);
            }
            else if(levelKind == "saloonKind")
            {
                //���һ���ƹݹؿ�id
                avaLevelId = 1014; 

                levelItem = btn.gameObject.AddComponent(System.Type.GetType("SaloonLevel")) as BaseLevel;
                levelItemList.Add(levelItem);
            }
            else
            {
                //���һ�����عؿ�id
                avaLevelId = 1015; 

                levelItem = btn.gameObject.AddComponent(System.Type.GetType("TruesureLevel")) as BaseLevel;
                levelItemList.Add(levelItem);
            }

            //�ؿ�����
            levelItem.levelKind = levelKind;

            //������
            btn.gameObject.name = avaLevelId.ToString();

            //����Ҫ�ı�ؿ����� ��Ҫ��

            levelItem.levelId = int.Parse(btn.gameObject.name);
            for(int i = 0; i < levelDataList.Count; i++)
            {
                if (levelDataList[i]["id"] == levelItem.levelId.ToString())
                {
                    levelItem.levelTitle = levelDataList[i]["title"];
                    levelItem.levelDes = levelDataList[i]["des"];
                    break;
                }
            }
            levelList.Add(btn);
        }//-----------------------------------------------------------------------------

        Init();
    }

    void Init()
    {
        //�ж��Ƿ����boss
        bool ifboss = LevelManager.Instance.ifBoss();
        //����boss�ؿ����ָ��ʣ�10��
        LevelManager.Instance.bossProAdd(10);

        //������boss ��ֻ��һ����ѡ�ؿ���Ϊboss
        if(ifboss)
        {
            for (int i = 0; i < levelItemList.Count; i++)
            {
                if (i >= 1)
                {
                    levelList[i].GetComponent<Image>().color = Color.black;
                    levelList[i].enabled = false;
                }
                else
                {
                    //���Ӷ�Ӧͼ�꣨boss��
                    GameObject icon = Instantiate(Resources.Load("UiItems/LevelIcons/bossKind")) as GameObject;
                    icon.transform.SetParent(levelItemList[i].transform);
                    icon.GetComponent<RectTransform>().anchoredPosition = Vector2.zero;
                    icon.GetComponent<RectTransform>().localScale = Vector2.one * UiFitter.ScaleFitVertical(1.5f);
                    //�޸����ֺ�levelId
                    if (levelList[i].GetComponent<FightLevel>() == null) //�����޸Ľű�
                    {
                        levelItemList[i].enabled = false;
                        FightLevel item = levelList[i].gameObject.AddComponent<FightLevel>();
                        if(curStage == 1)
                            item.gameObject.name = "1012";
                        else if(curStage == 2)
                            item.gameObject.name = "1024";
                        item.levelId = int.Parse(item.gameObject.name);

                        for (int j = 0; j < levelDataList.Count; j++)
                        {
                            if (levelDataList[j]["id"] == item.levelId.ToString())
                            {
                                item.levelTitle = levelDataList[j]["title"];
                                item.levelDes = levelDataList[j]["des"];
                                break;
                            }
                        }

                    }
                    else //�������޸Ľű�
                    {
                        if (curStage == 1)
                            levelItemList[i].gameObject.name = "1012";
                        else if(curStage == 2)
                            levelItemList[i].gameObject.name = "1024";
                        levelItemList[i].levelId = int.Parse(levelItemList[i].gameObject.name);

                        for (int j = 0; j < levelDataList.Count; j++)
                        {
                            if (levelDataList[j]["id"] == levelItemList[i].levelId.ToString())
                            {
                                levelItemList[i].levelTitle = levelDataList[j]["title"];
                                levelItemList[i].levelDes = levelDataList[j]["des"];
                                break;
                            }
                        }
                    }
                }
                LevelManager.Instance.bossPro = 0; //����boss���ֵĸ���
            }
            RoleManager.Instance.AddCurStage(1);
            return;
        }

        //��ѡ�ؿ�����
        int choiceNum = LevelManager.Instance.GetChoiceNum();
        for (int i = 0; i < levelItemList.Count; i++)
        {
            if (i >= choiceNum)
            {
                levelList[i].GetComponent<Image>().color = Color.black;
                levelList[i].gameObject.SetActive(false);
                levelList[i].enabled = false;
            }
            else
            {
                //���Ӷ�Ӧͼ��
                GameObject icon = Instantiate(Resources.Load("UiItems/LevelIcons/" + levelItemList[i].levelKind)) as GameObject;
                print("levelKind:" + levelItemList[i].levelKind);
                icon.transform.SetParent(levelItemList[i].transform);
                icon.GetComponent<RectTransform>().anchoredPosition = Vector2.zero;
                icon.GetComponent<RectTransform>().localScale = Vector2.one * UiFitter.ScaleFitVertical(1.5f);
            }
        }
    }

    // Update is called once per frame
    void Update()
    {

    }
}
