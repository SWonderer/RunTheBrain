using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SaloonUI : UIBase
{
    public Button DeleteEffectBtn;
    public Button AddCardBtn;

    public GameObject EffPanel;

    public string myEffs;

    // Start is called before the first frame update
    void Start()
    {
        DeleteEffectBtn = GameObject.Find("DeleteEffectBtn").GetComponent<Button>();
        DeleteEffectBtn.onClick.AddListener(OnClickDeleteEffectBtn);
        AddCardBtn = GameObject.Find("AddCardBtn").GetComponent<Button>();
        AddCardBtn.onClick.AddListener(OnClickAddCardBtn);
    }

    //ɾ��һ����ͼ����Ч��
    public void OnClickDeleteEffectBtn()
    {
        myEffs = RoleManager.Instance.fieldEffects;

        //����RoleManager����Ϣչʾ���е�ͼ����Ч��������EffBtnԤ���壬��װ��Ӧ��icon�����谴ť����
        GameObject effPanel = GameObject.Instantiate(Resources.Load("UiItems/EffPanel")) as GameObject;
        effPanel.transform.SetParent(GameObject.Find("Canvas").transform);
        effPanel.GetComponent<RectTransform>().anchoredPosition = Vector2.zero;
        effPanel.GetComponent<RectTransform>().localScale = UiFitter.ScaleFitHorizontal(1) * Vector3.one;
        effPanel.transform.SetAsLastSibling();
        effPanel.name = "EffPanel";
        GameObject.Find("EffPanel/BackBtn").GetComponent<Button>().onClick.AddListener(OnClickEffPanelBackBtn);
        EffPanel = effPanel;

        //RoleManger��ȡ
        myEffs = myEffs.Trim();
        string[] effList = myEffs.Split(",");
        List<string> effTypeList = new List<string>();
        List<string> effValList = new List<string>();
        for(int i = 0; i < effList.Length; i++)
        {
            string c = "0";
            int temp = 0;
            string effType = "";
            string effVal = "0";
            for(int j = 0; j < effList[i].Length; j++)
            {
                c = effList[i][j].ToString();
                if (isNum(c, temp))
                    effVal = (int.Parse(effVal) * 10 + int.Parse(c)).ToString();
                else
                    effType += c;
            }
            effTypeList.Add(effType);
            effValList.Add(effVal);
        }

        //���140������panel��
        for(int i = 0; i < effTypeList.Count; i++)
        {
            GameObject effObj = GameObject.Instantiate(Resources.Load("UiItems/EffBtn")) as GameObject;
            effObj.transform.SetParent(GameObject.Find("EffPanel/EffBtns").transform);
            effObj.GetComponent<RectTransform>().anchoredPosition = new Vector2(-(effTypeList.Count - 1) * 70 + i * 140, 0);
            effObj.name = effTypeList[i] + effValList[i];
            effObj.GetComponentInChildren<Text>().text = effValList[i];
            effObj.GetComponent<RectTransform>().localScale = Vector2.one * UiFitter.ScaleFitHorizontal(1);
            DeleteEffInSaloon item = effObj.AddComponent<DeleteEffInSaloon>();
            item.effType = effTypeList[i];
            item.effVal = effValList[i];
            item.effTypeList = effTypeList;
            item.effValList = effValList;

            GameObject effIcon = GameObject.Instantiate(Resources.Load("UiItems/EffIcons/" + effTypeList[i])) as GameObject;
            effIcon.transform.SetParent(effObj.transform);
            effIcon.GetComponent<RectTransform>().anchoredPosition = Vector2.zero;
            effIcon.name = "icon";
            effIcon.GetComponent<RectTransform>().localScale = Vector2.one * UiFitter.ScaleFitHorizontal(1);
        }
    }

    public bool isNum(string s, int re)
    {
        bool isnum = false;
        isnum = int.TryParse(s, out re);
        return isnum;
    }

    public void OnClickEffPanelBackBtn()
    {
        Destroy(EffPanel);
        EffPanel = null;
    }

    //����һ�ſ���
    public void OnClickAddCardBtn()
    {
        int randNum = Random.Range(1, 6);
        string cardName = "";
        switch (randNum)
        {
            case 1:
                cardName = "Down0Card";
                break;
            case 2:
                cardName = "Down2Card";
                break;
            case 3:
                cardName = "Up2Card";
                break;
            case 4:
                cardName = "Right2Card";
                break;
            case 5:
                cardName = "Left2Card";
                break;
            default:
                break;
        }
        RoleManager.Instance.playerCards.Add(cardName);
        UIManager.Instance.ShowTip("����˿��ƣ�" + cardName, Color.red);
        UIManager.Instance.ClearAllUI();
        UIManager.Instance.CreateUIByName("LevelUI");
    }
}
