using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//UI���ö��
public enum UIStage
{
    None,
    FightUI,
    LoginUI
}


//UI������
public class UIManager : MonoBehaviour
{
    public static UIManager Instance;

    public List<UIBase> UIList;

    public GameObject hurtEffPanel;

    public List<GameObject> DesContainerObjList = new List<GameObject>();

    public void Awake()
    {
        Instance = this;
    }

    //��ʼ��
    public void Init()
    {
        //���ɱ���ui
        CreateUIByName("LoginUI");
        CreateHurtEffPanel();
    }

    public void CreateHurtEffPanel()
    {
        hurtEffPanel = GameObject.Instantiate(Resources.Load("UiItems/HurtEffPanel") as GameObject);
        hurtEffPanel.transform.SetParent(GameObject.Find("Canvas").transform);
        hurtEffPanel.GetComponent<RectTransform>().anchoredPosition = Vector2.zero;
        hurtEffPanel.name = "HurtEffPanel";
        hurtEffPanel.SetActive(false);
    }

    //��ɫ�ܻ���Ļ���Ч��
    public void ShowRedPanel(float time)
    {
        StartCoroutine(ShowPanel(time));
    }

    IEnumerator ShowPanel(float time)
    {
        hurtEffPanel.SetActive(true);
        yield return new WaitForSeconds(time);
        hurtEffPanel.SetActive(false);
    }

    //����ĳ��UI UI�������������ͳһ
    public void CreateUIByName(string uiName)
    {
        GameObject uiObj = GameObject.Instantiate(Resources.Load("UI/" + uiName)) as GameObject;
        uiObj.transform.SetParent(GameObject.Find("Canvas").transform);
        uiObj.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, 0);
        uiObj.transform.SetAsLastSibling();
        uiObj.transform.localScale = UiFitter.ScaleFitHorizontal(1) * Vector3.one; //��С����ֱ���
        UIBase uiItem = uiObj.AddComponent(System.Type.GetType(uiName)) as UIBase;
        UIList.Add(uiItem);
        uiObj.transform.name = uiName;
    }

    //�������ui
    public void ClearAllUI()
    {
        while(UIList.Count > 0)
        {
            UIList[0].SelfDestroy();
            UIList.RemoveAt(0);
        }
    }

    public void CreateFightScene()
    {
        CreateUIByName("FightUI");
        GameManager.Instance.FightSceneInit();
    }

    public void ShowTip(string txt, Color color, float duration = 1.0f)
    {
        GameObject tip = GameObject.Instantiate(Resources.Load("UiItems/Tip")) as GameObject;
        tip.transform.SetParent(GameObject.Find("Canvas").transform);
        tip.name = "Tip";
        tip.transform.SetAsLastSibling();
        tip.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, 0);
        tip.GetComponentInChildren<Text>().color = color;
        tip.GetComponentInChildren<Text>().text = txt;
        StartCoroutine(DestroyTip(duration, tip));
    }

    IEnumerator DestroyTip(float duration, GameObject tip)
    {
        yield return new WaitForSeconds(duration);
        Destroy(tip);
    }

    GameObject panelObj;

    public void ShowEndBattlePanel(string txt, Color color)
    {
        GameObject panelObj = GameObject.Instantiate(Resources.Load("UiItems/EndBattlePanel")) as GameObject;
        panelObj.transform.SetParent(GameObject.Find("Canvas").transform);
        panelObj.name = "EndBattlePanel";
        panelObj.transform.SetAsLastSibling();
        panelObj.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, 0);
        panelObj.GetComponentInChildren<Text>().color = color;
        panelObj.GetComponentInChildren<Text>().text = txt;
        this.panelObj = panelObj;
        EndBattlePanel panelItem = panelObj.AddComponent<EndBattlePanel>();
        GameObject.Find("EndBattlePanel/CloseBtn").GetComponent<Button>().onClick.AddListener(OnClickCloseEndBattlePanelBtn);
    }

    public void OnClickCloseEndBattlePanelBtn()
    {
        //�رոý��棬����ѡ��UI���ر�ս��UI������RoleManager�е�Ѫ������ǰ�ؿ�������һ
        RoleManager.Instance.UpdateCurHp(PlayerController.Instance.curHp);
        Destroy(panelObj);
        ClearAllUI();
        GameManager.Instance.FightSceneClear();
        CreateUIByName("LevelUI");
    }

    GameObject winOrLosePanelObj;

    public void ShowWinOrLosePanel(string txt, Color color)
    {
        GameObject panelObj = GameObject.Instantiate(Resources.Load("UiItems/WinOrLosePanel")) as GameObject;
        panelObj.transform.SetParent(GameObject.Find("Canvas").transform);
        panelObj.name = "WinOrLosePanel";
        panelObj.transform.SetAsLastSibling();
        panelObj.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, 0);
        panelObj.GetComponentInChildren<Text>().color = color;
        panelObj.GetComponentInChildren<Text>().text = txt;
        this.winOrLosePanelObj = panelObj;
        GameObject.Find("WinOrLosePanel/CloseBtn").GetComponent<Button>().onClick.AddListener(OnClickWinOrLosePanelBtn);
    }

    public void OnClickWinOrLosePanelBtn()
    {
        //�رոý��棬����LoginUI
        RoleManager.Instance.Init();
        Destroy(winOrLosePanelObj);
        ClearAllUI();
        GameManager.Instance.FightSceneClear();
        CreateUIByName("LoginUI");
    }

    public void ShowDesContainer(Vector2 pos, string title, string content, Color color, string name = "DesContainer") //ΪʲôColor���ܼ�Ĭ��ֵ��
    {
        GameObject desObj = GameObject.Instantiate(Resources.Load("UiItems/DesContainer")) as GameObject;
        DesContainerObjList.Add(desObj);
        desObj.transform.SetParent(GameObject.Find("Canvas/theDesContainer").transform);
        desObj.name = name;
        desObj.transform.SetAsFirstSibling();
        GameObject.Find(name + "/img/title").GetComponent<Text>().text = title;
        GameObject.Find(name + "/img/content").GetComponent<Text>().text = content;
        desObj.GetComponent<RectTransform>().anchoredPosition = pos;
        desObj.GetComponent<RectTransform>().localScale = UiFitter.ScaleFitHorizontal(1) * Vector2.one;
        GameObject.Find(name + "/img/title").GetComponent<Text>().color = color;
        GameObject.Find(name + "/img/content").GetComponent<Text>().color = color;
    }

    public void DestoyAllDesContainer()
    {
        if(DesContainerObjList != null)
        {
            for(int i = 0; i < DesContainerObjList.Count; i++)
            {
                Destroy(DesContainerObjList[i]);
            }
        }
    }
}
