using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Effect_AddCards : BaseEffect
{
    public void Awake()
    {
        for (int i = 0; i < this.GetComponent<BaseField>().icons.Count; i++)
        {
            this.GetComponent<BaseField>().icons[i].SetActive(false);
        }
        this.GetComponent<BaseField>().DrawCardsIcon.SetActive(true);
    }

    public override void StrikeEffect()
    {
        for(int i = 0; i < val; i++)
        {
            string cardName = CardController.Instance.DrawFirstCard();
            CardController.Instance.CreateCardByPos(cardName, GameObject.Find("cardFlyStart").GetComponent<RectTransform>().anchoredPosition);
            CardController.Instance.UpdateHandCardPos();
        }
        Debug.Log("�����˳鿨���Ч��" + val);
    }
}
