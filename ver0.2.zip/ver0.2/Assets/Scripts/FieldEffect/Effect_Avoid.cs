using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Effect_Avoid : BaseEffect
{
    public void Awake()
    {
        for (int i = 0; i < this.GetComponent<BaseField>().icons.Count; i++)
        {
            this.GetComponent<BaseField>().icons[i].SetActive(false);
        }
        this.GetComponent<BaseField>().AvoidIcon.SetActive(true);
    }

    public override void StrikeEffect()
    {
        PlayerController.Instance.avoid_addable += val;
        Debug.Log("���������ܸ��Ч��" + val);
    }
}
