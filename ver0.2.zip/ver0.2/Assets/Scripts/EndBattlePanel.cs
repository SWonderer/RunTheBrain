using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EndBattlePanel : MonoBehaviour
{
    public static EndBattlePanel Instance;

    public List<GameObject> EffRewards = new List<GameObject>(); //Ч����Ϸ�����б�

    public List<Dictionary<string, string>> EffLines = new List<Dictionary<string, string>>();

    //����buff���ָ����ܺ�
    public int probabilitySum1 = 0;

    //�����ж�����������ĸ�����
    public int probabilitySum2 = 0;

    void Awake()
    {
        Instance = this;

        EffLines = GameConfigManager.Instance.GetEffectLines();

        foreach(Dictionary<string, string> line in EffLines)
        {
            probabilitySum1 += int.Parse(line["probability"]);
        }

        Init();
    }

    public string GetRandEffId()
    {
        //����� ���������ȡ���ſ���
        int randNumVariety = Random.Range(1, probabilitySum1);
        print("randNumVarirty" + randNumVariety);

        probabilitySum2 = 0;

        for (int i = 0; i < EffLines.Count; i++)
        {
            probabilitySum2 += int.Parse(EffLines[i]["probability"]);
            print("pro:" + probabilitySum2);
            if (probabilitySum2 >= randNumVariety)
            {
                return EffLines[i]["id"];
            }
        }
        return null;
    }

    //��ȡ����н��������߳��ָ����Լ���ֵ
    public int GetNumByPro(Dictionary<string, string> dic)
    {
        //��ȡһ�������
        int randNum;
        int proCount = 0;
        //��������Ʒ�ʳ��ָ���
        int goldPro = 0;
        int goldNum = 0;
        int silverPro = 0;
        int silverNum = 0;
        int steelPro = 0;
        int steelNum = 0;
        //������ʱ���ַ���
        string goldNumAndPro = dic["goldNum/pro"];
        goldNumAndPro = goldNumAndPro.Trim();
        string[] gNumAPro = goldNumAndPro.Split(","); //���ڷָ��ַ�����ȡ��Ϣ
        if(goldNumAndPro != "-")
        {
            goldPro = int.Parse(gNumAPro[1]);
            goldNum = int.Parse(gNumAPro[0]); //��ȡ����ֵ�͸���
        }

        string silverNumAndPro = dic["silverNum/pro"];
        silverNumAndPro = silverNumAndPro.Trim();
        string[] sNumAPro = silverNumAndPro.Split(","); //���ڷָ��ַ�����ȡ��Ϣ
        if(silverNumAndPro != "-")
        {
            silverPro = int.Parse(sNumAPro[1]);
            silverNum = int.Parse(sNumAPro[0]); //��ȡ����ֵ�͸���
        }

        string steelNumAndPro = dic["steelNum/pro"];
        steelNumAndPro = steelNumAndPro.Trim();
        string[] stNumAPro = steelNumAndPro.Split(","); //���ڷָ��ַ�����ȡ��Ϣ
        if(steelNumAndPro != "-")
        {
            steelPro = int.Parse(stNumAPro[1]);
            steelNum = int.Parse(stNumAPro[0]); //��ȡ����ֵ�͸���
        }

        randNum = Random.Range(0, 100);
        proCount += goldPro;
        if (proCount >= randNum)
            return goldNum;
        proCount += silverPro;
        if (proCount >= randNum)
            return silverNum;
        proCount += steelPro;
        if(proCount >= randNum)
            return steelNum;
        return 0;
    }

    public void Init()
    {
        Dictionary<string, string> dic1 = GameConfigManager.Instance.GetEffectById(GetRandEffId());
        CreateEffectRewards(dic1["effectName"], GetNumByPro(dic1), Vector2.zero, 1001);
        print("name1:" + dic1["effectName"]);
        Dictionary<string, string> dic2 = GameConfigManager.Instance.GetEffectById(GetRandEffId());
        CreateEffectRewards(dic2["effectName"], GetNumByPro(dic2), new Vector2(UiFitter.PosFitHorizontal(400), 0), 1002);
        print("name2:" + dic2["effectName"]);
        Dictionary<string, string> dic3 = GameConfigManager.Instance.GetEffectById(GetRandEffId());
        CreateEffectRewards(dic3["effectName"], GetNumByPro(dic3), new Vector2(UiFitter.PosFitHorizontal(-400), 0), 1003);
        print("name3:" + dic3["effectName"]);
    }

    public void CreateEffectRewards(string effName, int value, Vector2 pos, int id)
    {
        //���뽱��Ч����Դ
        GameObject rewardObj = GameObject.Instantiate(Resources.Load("UiItems/EffectReward")) as GameObject;
        //ȷ���㼶
        rewardObj.transform.SetParent(GameObject.Find("EndBattlePanel/Rewards").transform);
        rewardObj.transform.SetAsLastSibling();
        //������
        rewardObj.name = "EffectReward" + id.ToString();
        //����ui
        rewardObj.transform.localScale = UiFitter.ScaleFitHorizontal(1) * Vector3.one;
        //ȷ��λ��
        rewardObj.GetComponent<RectTransform>().anchoredPosition = pos;
        //�����б�
        EffRewards.Add(rewardObj);
        //ȷ�����ݣ����ͺ���ֵ��
        GameObject iconObj = GameObject.Instantiate(Resources.Load("UiItems/EffIcons/" + effName)) as GameObject;
        iconObj.transform.SetParent(GameObject.Find(rewardObj.name + "/BackGround").transform);
        iconObj.GetComponent<RectTransform>().anchoredPosition = Vector2.zero + new Vector2(0, 100);
        iconObj.transform.SetAsFirstSibling();
        iconObj.transform.localScale = UiFitter.ScaleFitHorizontal(1) * Vector3.one;
        iconObj.name = "icon";
        GameObject.Find(rewardObj.name + "/BackGround").GetComponentInChildren<Text>().text = value.ToString();
        NameTagger nameTagItem = GameObject.Find(rewardObj.name + "/BackGround/nameTag").AddComponent<NameTagger>();
        nameTagItem.nameTag = effName + value.ToString();
        //���ؽű�
        RewardEff rewardItem = rewardObj.AddComponent<RewardEff>();
    }

    public void ClearAllEffRewards()
    {
        for(int i = 0; i < EffRewards.Count; i++)
        {
            EffRewards[i].GetComponent<RewardEff>().SelfDestory();
        }
    }
}
